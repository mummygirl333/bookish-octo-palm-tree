// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title IPRoyaltyRegistry
 * @notice First-claim IP asset registry with voluntary USDC royalties and owner pull payments.
 * @dev Supports works, data, software, designs, and other kinds of intellectual property.
 *      Registration records a claim, not proof of legal ownership or proof of offchain usage.
 *      Prices and payments use USDC base units (6 decimals on Arc). No administrator,
 *      protocol fees, upgrades, or sweep exists. Unclaimed royalties follow asset ownership.
 *      Each accepted payment is fully credited and each claim debits exactly its payout.
 *      Absolute balance equality cannot be enforced: anyone can transfer ERC20 tokens directly
 *      to this address without invoking the registry. Such unsolicited tokens are not credited
 *      and cannot be recovered. Use only the intended non-rebasing, fee-free USDC contract.
 */
contract IPRoyaltyRegistry is ReentrancyGuard {
    using SafeERC20 for IERC20;

    /// @notice IP asset claim, pricing, and lifetime royalty accounting.
    struct Asset {
        /// @notice Current claimant and sole recipient of withdrawals.
        address owner;
        /// @notice Whether new royalty payments are accepted; withdrawals remain available.
        bool active;
        /// @notice USDC base units charged per use; zero disables per-use payments.
        uint96 pricePerUse;
        /// @notice Unique, nonzero content commitment; immutable after registration.
        bytes32 contentHash;
        /// @notice Metadata pointer, between 1 and 256 bytes; immutable after registration.
        string uri;
        /// @notice 0 Data, 1 Image or art, 2 Audio or video, 3 Writing, 4 Software,
        ///         5 Design or patent, 6 Other, 7 Personal experience or research; immutable after registration.
        uint8 kind;
        /// @notice License terms pointer, at most 256 bytes and possibly empty; immutable after registration.
        string licenseUri;
        /// @notice Registration time as a Unix timestamp in seconds.
        uint64 registeredAt;
        /// @notice Self-declared original creation time; zero means unknown. Immutable, a declaration, not proof.
        uint64 createdAt;
        /// @notice Immutable permission to transfer; false permanently retains the registering wallet as owner.
        bool transferable;
        /// @notice Total declared uses paid through payForUsage only.
        uint256 totalUses;
        /// @notice Lifetime USDC royalties credited, including amounts already claimed.
        uint256 totalEarned;
        /// @notice USDC royalties available to the current owner.
        uint256 unclaimed;
        /// @notice Immutable hash of an off-chain copyright registration document; zero means none.
        /// @dev Self-declared reference, never verified. Identity or biometric data must never be
        ///      placed onchain; supply only a hash, never the underlying data.
        bytes32 copyrightRef;
        /// @notice Number of timestamped, unverified unauthorized-use notices recorded by owners.
        uint256 noticeCount;
    }

    /// @notice Immutable registration fields supplied by the registering wallet.
    struct Registration {
        /// @notice 0 Data, 1 Image or art, 2 Audio or video, 3 Writing, 4 Software,
        ///         5 Design or patent, 6 Other, 7 Personal experience or research.
        uint8 kind;
        /// @notice Metadata pointer of 1 to 256 bytes.
        string uri;
        /// @notice License terms pointer of 0 to 256 bytes; may be empty.
        string licenseUri;
        /// @notice Unique nonzero hash committing to the asset's content.
        bytes32 contentHash;
        /// @notice Initial USDC base units per use; may be zero.
        uint96 pricePerUse;
        /// @notice Self-declared original creation timestamp, not proof; zero means unknown; cannot be in the future.
        uint64 createdAt;
        /// @notice Whether the registering wallet permits future ownership transfers.
        bool transferable;
        /// @notice Hash of an off-chain copyright registration document; zero means none. Immutable after registration.
        /// @dev Self-declared reference, never verified. Identity or biometric data must never be
        ///      placed onchain; supply only a hash, never the underlying data.
        bytes32 copyrightRef;
    }

    /// @notice Payment token supplied at construction; expected to be Arc USDC.
    IERC20 public immutable usdc;
    /// @notice Number of registered assets; valid IDs are 1 through this value.
    uint256 public assetCount;
    /// @notice Maximum number of IDs accepted by claimMany.
    uint256 public constant MAX_CLAIM_BATCH = 50;
    /// @notice Maximum number of assets returned in one page.
    uint256 public constant MAX_PAGE_SIZE = 100;
    /// @notice Maximum metadata or license URI size in bytes.
    uint256 public constant MAX_URI_BYTES = 256;
    /// @notice Largest supported IP asset kind (Personal experience or research).
    uint8 public constant MAX_KIND = 7;
    /// @notice Content hash to permanent asset ID; zero means unregistered.
    mapping(bytes32 => uint256) public assetIdByHash;
    /// @notice Registration commitment to its commit block; zero means not committed.
    mapping(bytes32 => uint256) public commitBlockOf;
    /// @dev Asset records keyed by their 1-based IDs.
    mapping(uint256 => Asset) private _assets;

    /// @notice A token or new owner address was zero.
    error ZeroAddress();
    /// @notice The payment token must have code and use six decimals.
    error InvalidPaymentToken(address token);
    /// @notice The requested asset does not exist.
    error AssetNotFound(uint256 id);
    /// @notice Only the asset's current owner can perform this operation.
    error NotAssetOwner(uint256 id, address caller);
    /// @notice The evidence hash cannot be zero.
    error ZeroEvidenceHash();
    /// @notice The content hash cannot be zero.
    error ZeroContentHash();
    /// @notice A registration commitment cannot be zero.
    error ZeroCommitment();
    /// @notice The registration commitment has already been submitted.
    error CommitmentAlreadyExists(bytes32 commitment);
    /// @notice The caller has not submitted the required registration commitment.
    error CommitmentMissing(bytes32 commitment);
    /// @notice Registration must occur in a block after the commitment.
    error CommitmentNotReady(bytes32 commitment, uint256 committedAtBlock, uint256 currentBlock);
    /// @notice The content hash already has a first claimant.
    error ContentHashRegistered(bytes32 contentHash, uint256 id);
    /// @notice Metadata URI must be 1 to MAX_URI_BYTES; license and notice URIs must be 0 to MAX_URI_BYTES.
    error InvalidUriLength(uint256 length);
    /// @notice The asset kind exceeds MAX_KIND.
    error InvalidKind(uint8 kind);
    /// @notice The self-declared original creation time is in the future.
    error InvalidCreatedAt(uint64 createdAt);
    /// @notice The asset permanently disallows ownership transfers.
    error NotTransferable(uint256 id);
    /// @notice Inactive assets cannot receive new payments.
    error AssetInactive(uint256 id);
    /// @notice Per-use payments require a nonzero price.
    error ZeroPrice(uint256 id);
    /// @notice The current per-use price exceeds the payer's maximum.
    error PriceTooHigh(uint256 current, uint256 max);
    /// @notice A usage payment must report at least one use.
    error ZeroUses();
    /// @notice Custom royalty payments must have a nonzero amount.
    error ZeroAmount();
    /// @notice Token balance movement did not equal the requested payment.
    error UnexpectedReceivedAmount(uint256 expected, uint256 balanceBefore, uint256 balanceAfter);
    /// @notice A claim had no accrued royalties to pay.
    error NothingToClaim();
    /// @notice A batch must contain between 1 and MAX_CLAIM_BATCH IDs.
    error InvalidBatchLength(uint256 length);
    /// @notice Pagination begins at a 1-based asset ID, never zero.
    error InvalidStart();

    /// @notice A registration commitment was submitted for a later-block reveal.
    event RegistrationCommitted(bytes32 indexed commitment, address indexed owner);
    /// @notice A first claimant registered an IP asset of the specified kind.
    event AssetRegistered(
        uint256 indexed id, address indexed owner, bytes32 indexed contentHash, uint8 kind, string uri, uint96 pricePerUse
    );
    /// @notice The owner changed the USDC price per use.
    event PriceUpdated(uint256 indexed id, uint96 oldPrice, uint96 newPrice);
    /// @notice The owner changed whether new payments are accepted.
    event ActiveUpdated(uint256 indexed id, bool active);
    /// @notice Ownership, including all unclaimed royalties, moved to the new owner.
    event AssetTransferred(uint256 indexed id, address indexed previousOwner, address indexed newOwner);
    /// @notice A payer purchased declared uses; usageRef is an opaque, non-unique payer reference.
    event UsagePaid(uint256 indexed id, address indexed payer, uint256 uses, uint256 amount, bytes32 usageRef);
    /// @notice A payer funded a custom royalty without incrementing declared uses.
    event RoyaltyFunded(uint256 indexed id, address indexed payer, uint256 amount, bytes32 usageRef);
    /// @notice An owner claimed an asset balance; batch entries with zero balance emit zero.
    event RoyaltyClaimed(uint256 indexed id, address indexed owner, uint256 amount);
    /// @notice Timestamped owner statement, unverified, not a legal finding and not enforceable onchain.
    event UnauthorizedUseNoticed(
        uint256 indexed id,
        uint256 indexed noticeIndex,
        bytes32 evidenceHash,
        string noticeUri,
        uint64 recordedAt
    );

    /// @notice Configure the immutable payment token without assigning any administrative role.
    /// @param usdc_ Nonzero address of the intended USDC ERC20 contract.
    constructor(address usdc_) {
        if (usdc_ == address(0)) revert ZeroAddress();
        if (usdc_.code.length == 0 || IERC20Metadata(usdc_).decimals() != 6) {
            revert InvalidPaymentToken(usdc_);
        }
        usdc = IERC20(usdc_);
    }

    /// @notice Compute a registration commitment bound to its intended owner.
    /// @param owner Intended asset claimant.
    /// @param contentHash Hash committing to the asset's content.
    /// @param salt Secret salt to conceal the content hash until registration.
    /// @return commitment Hash to submit before revealing the registration.
    function registrationCommitment(address owner, bytes32 contentHash, bytes32 salt)
        public
        pure
        returns (bytes32 commitment)
    {
        return keccak256(abi.encode(owner, contentHash, salt));
    }

    /// @notice Commit to a registration that may be revealed in any later block.
    /// @param commitment Nonzero, previously unsubmitted registration commitment.
    function commitRegistration(bytes32 commitment) external {
        if (commitment == bytes32(0)) revert ZeroCommitment();
        if (commitBlockOf[commitment] != 0) revert CommitmentAlreadyExists(commitment);
        commitBlockOf[commitment] = block.number;
        emit RegistrationCommitted(commitment, msg.sender);
    }

    /// @notice Register an IP asset with immutable kind, content hash, pointers, creation declaration, and transfer policy.
    /// @dev Requires a matching commitment from an earlier block; commitments do not expire.
    ///      createdAt is a self-declaration, not proof of creation or ownership.
    ///      Non-transferable assets remain controlled solely by the registering wallet, with no recovery path.
    /// @param r Registration fields; kinds 0 through 7 are listed in Registration.
    /// @param salt Secret salt used in the caller-bound registration commitment.
    /// @return id Newly allocated 1-based asset ID.
    function registerAsset(Registration calldata r, bytes32 salt) external nonReentrant returns (uint256 id) {
        {
            bytes32 commitment = registrationCommitment(msg.sender, r.contentHash, salt);
            uint256 commitBlock = commitBlockOf[commitment];
            if (commitBlock == 0) revert CommitmentMissing(commitment);
            if (block.number <= commitBlock) revert CommitmentNotReady(commitment, commitBlock, block.number);
            delete commitBlockOf[commitment];
        }

        Asset memory asset;
        asset.kind = r.kind;
        asset.uri = r.uri;
        asset.licenseUri = r.licenseUri;
        asset.contentHash = r.contentHash;
        asset.pricePerUse = r.pricePerUse;
        asset.createdAt = r.createdAt;
        asset.transferable = r.transferable;
        asset.copyrightRef = r.copyrightRef;
        _validateRegistration(asset);
        id = _initializeAsset(asset);
    }

    /// @dev Validate registration fields in their original order; zero price remains allowed.
    function _validateRegistration(Asset memory asset) private view {
        if (asset.contentHash == bytes32(0)) revert ZeroContentHash();
        uint256 existingId = assetIdByHash[asset.contentHash];
        if (existingId != 0) revert ContentHashRegistered(asset.contentHash, existingId);
        if (asset.kind > MAX_KIND) revert InvalidKind(asset.kind);
        uint256 length = bytes(asset.uri).length;
        if (length == 0 || length > MAX_URI_BYTES) revert InvalidUriLength(length);
        uint256 licenseLength = bytes(asset.licenseUri).length;
        if (licenseLength > MAX_URI_BYTES) revert InvalidUriLength(licenseLength);
        if (asset.createdAt > block.timestamp) revert InvalidCreatedAt(asset.createdAt);
    }

    /// @dev Initialize a validated asset and emit its registration using grouped arguments.
    function _initializeAsset(Asset memory asset) private returns (uint256 id) {
        id = ++assetCount;
        assetIdByHash[asset.contentHash] = id;
        asset.owner = msg.sender;
        asset.active = true;
        asset.registeredAt = uint64(block.timestamp);
        _assets[id] = asset;
        emit AssetRegistered(id, msg.sender, asset.contentHash, asset.kind, asset.uri, asset.pricePerUse);
    }

    /// @notice Record a timestamped statement by the owner of alleged unauthorized use.
    /// @dev Unverified, not a legal finding and not enforceable onchain. Available even when
    ///      inactive or permanently non-transferable. Only the notice counter changes; no funds move.
    ///      Identity or biometric data must never be placed onchain; supply only hashes and safe pointers.
    /// @param id Asset currently owned by the caller.
    /// @param evidenceHash Nonzero hash of off-chain evidence, not the evidence itself.
    /// @param noticeUri Optional off-chain notice pointer of at most MAX_URI_BYTES bytes.
    /// @return noticeIndex Newly allocated 1-based notice index for this asset.
    function recordNotice(uint256 id, bytes32 evidenceHash, string calldata noticeUri)
        external
        nonReentrant
        returns (uint256 noticeIndex)
    {
        Asset storage asset = _ownedAsset(id);
        if (evidenceHash == bytes32(0)) revert ZeroEvidenceHash();
        uint256 length = bytes(noticeUri).length;
        if (length > MAX_URI_BYTES) revert InvalidUriLength(length);
        noticeIndex = ++asset.noticeCount;
        emit UnauthorizedUseNoticed(id, noticeIndex, evidenceHash, noticeUri, uint64(block.timestamp));
    }

    /// @notice Change the price for subsequent per-use payments; accrued royalties are unchanged.
    /// @param id Asset owned by the caller.
    /// @param newPrice New USDC base units per use; zero disables payForUsage.
    function setPrice(uint256 id, uint96 newPrice) external nonReentrant {
        Asset storage asset = _ownedAsset(id);
        uint96 oldPrice = asset.pricePerUse;
        asset.pricePerUse = newPrice;
        emit PriceUpdated(id, oldPrice, newPrice);
    }

    /// @notice Enable or disable new payments without restricting claims.
    /// @param id Asset owned by the caller.
    /// @param active Whether to accept subsequent payments.
    function setActive(uint256 id, bool active) external nonReentrant {
        _ownedAsset(id).active = active;
        emit ActiveUpdated(id, active);
    }

    /// @notice Transfer an asset and ALL its unclaimed royalties immediately to a new owner.
    /// @dev Only assets registered as transferable can move. The old owner loses the ability to claim;
    ///      no balance is paid during transfer.
    /// @param id Asset owned by the caller.
    /// @param newOwner Nonzero recipient responsible for retaining access to its account.
    function transferAsset(uint256 id, address newOwner) external nonReentrant {
        Asset storage asset = _ownedAsset(id);
        if (!asset.transferable) revert NotTransferable(id);
        if (newOwner == address(0)) revert ZeroAddress();
        asset.owner = newOwner;
        emit AssetTransferred(id, msg.sender, newOwner);
    }

    /// @notice Pay the current price, bounded by the payer's maximum, after approving this registry.
    /// @dev Checked multiplication reverts on overflow. References are not deduplicated.
    ///      The event is intentionally emitted after the received-amount check.
    /// @param id Active asset to credit.
    /// @param uses Positive number of uses; does not verify actual offchain use.
    /// @param maxPricePerUse Maximum acceptable USDC base units per use at execution time.
    /// @param usageRef Opaque payer-chosen reference, such as a site/feature/report hash.
    function payForUsage(uint256 id, uint256 uses, uint256 maxPricePerUse, bytes32 usageRef) external nonReentrant {
        Asset storage asset = _activeAsset(id);
        if (asset.pricePerUse == 0) revert ZeroPrice(id);
        if (uses == 0) revert ZeroUses();
        if (asset.pricePerUse > maxPricePerUse) revert PriceTooHigh(asset.pricePerUse, maxPricePerUse);
        uint256 amount = uint256(asset.pricePerUse) * uses;
        _pullAndCredit(asset, amount);
        asset.totalUses += uses;
        emit UsagePaid(id, msg.sender, uses, amount, usageRef);
    }

    /// @notice Pay a custom royalty after approval, independently of the asset's unit price.
    /// @dev Does not increment totalUses. References may be zero or reused.
    ///      The event is intentionally emitted after the received-amount check.
    /// @param id Active asset to credit.
    /// @param amount Positive royalty amount in USDC base units.
    /// @param usageRef Opaque payer-chosen usage or agreement reference.
    function fundRoyalty(uint256 id, uint256 amount, bytes32 usageRef) external nonReentrant {
        Asset storage asset = _activeAsset(id);
        if (amount == 0) revert ZeroAmount();
        _pullAndCredit(asset, amount);
        emit RoyaltyFunded(id, msg.sender, amount, usageRef);
    }

    /// @notice Withdraw all accrued royalties for an asset, even if it is inactive.
    /// @param id Asset currently owned by the caller.
    /// @return amount USDC base units transferred to the caller.
    function claim(uint256 id) external nonReentrant returns (uint256 amount) {
        Asset storage asset = _ownedAsset(id);
        amount = asset.unclaimed;
        if (amount == 0) revert NothingToClaim();
        asset.unclaimed = 0;
        emit RoyaltyClaimed(id, msg.sender, amount);
        usdc.safeTransfer(msg.sender, amount);
    }

    /// @notice Claim up to 50 asset entries with one aggregate USDC transfer.
    /// @dev Every ID must exist and be owned by the caller, including zero-balance entries.
    ///      All entries emit events; repeated IDs contribute zero after their first occurrence.
    ///      Reverts atomically if the aggregate is zero. Inactive assets remain claimable.
    /// @param ids Asset IDs, including any zero-balance entries the caller wants processed.
    /// @return total Aggregate USDC base units transferred to the caller.
    function claimMany(uint256[] calldata ids) external nonReentrant returns (uint256 total) {
        uint256 length = ids.length;
        if (length == 0 || length > MAX_CLAIM_BATCH) revert InvalidBatchLength(length);
        for (uint256 i = 0; i < length; ++i) {
            Asset storage asset = _ownedAsset(ids[i]);
            uint256 amount = asset.unclaimed;
            asset.unclaimed = 0;
            total += amount;
            emit RoyaltyClaimed(ids[i], msg.sender, amount);
        }
        if (total == 0) revert NothingToClaim();
        usdc.safeTransfer(msg.sender, total);
    }

    /// @notice Read an asset's balance available to its current owner, regardless of activity.
    /// @param id Existing asset ID.
    /// @return amount Unclaimed USDC base units.
    function claimable(uint256 id) external view returns (uint256 amount) {
        return _existingAsset(id).unclaimed;
    }

    /// @notice Read every field of an asset; nonexistent IDs revert.
    /// @param id Existing asset ID.
    /// @return asset Snapshot of the asset, including kind, URIs, and royalty accounting.
    function getAsset(uint256 id) external view returns (Asset memory asset) {
        return _existingAsset(id);
    }

    /// @notice Read a page of assets and their corresponding IDs in ascending ID order.
    /// @dev The range is clamped at assetCount; a start beyond it returns empty arrays.
    ///      Zero limit returns empty arrays. Limits greater than 100 are capped to 100.
    /// @param start First 1-based ID to include; zero reverts.
    /// @param limit Requested number of entries.
    /// @return assets Asset snapshots aligned with ids.
    /// @return ids Corresponding asset IDs.
    function getAssets(uint256 start, uint256 limit)
        external
        view
        returns (Asset[] memory assets, uint256[] memory ids)
    {
        if (start == 0) revert InvalidStart();
        uint256 length;
        if (start <= assetCount) {
            length = assetCount - start + 1;
            if (limit < length) length = limit;
            if (length > MAX_PAGE_SIZE) length = MAX_PAGE_SIZE;
        }
        assets = new Asset[](length);
        ids = new uint256[](length);
        for (uint256 i = 0; i < length; ++i) {
            uint256 id = start + i;
            ids[i] = id;
            assets[i] = _assets[id];
        }
    }

    /// @dev Resolve an existing asset without imposing ownership or activity requirements.
    /// @param id Asset ID to validate.
    /// @return asset Storage reference to the existing record.
    function _existingAsset(uint256 id) private view returns (Asset storage asset) {
        asset = _assets[id];
        if (asset.owner == address(0)) revert AssetNotFound(id);
    }

    /// @dev Resolve an existing asset owned by msg.sender, regardless of activity.
    /// @param id Asset ID to validate.
    /// @return asset Storage reference to the caller-owned record.
    function _ownedAsset(uint256 id) private view returns (Asset storage asset) {
        asset = _existingAsset(id);
        if (asset.owner != msg.sender) revert NotAssetOwner(id, msg.sender);
    }

    /// @dev Resolve an existing asset accepting new payments.
    /// @param id Asset ID to validate.
    /// @return asset Storage reference to the active record.
    function _activeAsset(uint256 id) private view returns (Asset storage asset) {
        asset = _existingAsset(id);
        if (!asset.active) revert AssetInactive(id);
    }

    /// @dev Pull exactly amount from msg.sender before crediting royalties; caller holds the lock.
    /// @param asset Record receiving the full payment, with no protocol deductions.
    /// @param amount Positive USDC base units to pull and credit.
    function _pullAndCredit(Asset storage asset, uint256 amount) private {
        uint256 balanceBefore = usdc.balanceOf(address(this));
        usdc.safeTransferFrom(msg.sender, address(this), amount);
        uint256 balanceAfter = usdc.balanceOf(address(this));
        if (balanceAfter < balanceBefore || balanceAfter - balanceBefore != amount) {
            revert UnexpectedReceivedAmount(amount, balanceBefore, balanceAfter);
        }
        asset.unclaimed += amount;
        asset.totalEarned += amount;
    }
}
