// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IPRoyaltyRegistryTestBase} from "./IPRoyaltyRegistry.Base.t.sol";
import {IPRoyaltyRegistry} from "../IPRoyaltyRegistry.sol";
import {MockERC20} from "../test-helpers/MockERC20.sol";

contract IPRoyaltyRegistryRegisterTest is IPRoyaltyRegistryTestBase {
    bytes32 internal constant H1 = keccak256("content1");
    bytes32 internal constant H2 = keccak256("content2");

    // ---- constructor ----
    function test_Constructor_SetsUsdcAndConstants() public view {
        assertEq(address(reg.usdc()), address(usdc));
        assertEq(reg.assetCount(), 0);
        assertEq(reg.MAX_CLAIM_BATCH(), 50);
        assertEq(reg.MAX_PAGE_SIZE(), 100);
        assertEq(reg.MAX_URI_BYTES(), 256);
        assertEq(reg.MAX_KIND(), 7);
    }

    function test_Constructor_RevertsOnZeroAddress() public {
        vm.expectRevert(IPRoyaltyRegistry.ZeroAddress.selector);
        new IPRoyaltyRegistry(address(0));
    }

    function test_Constructor_RevertsOnNoCodeToken() public {
        address eoa = makeAddr("notAToken");
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidPaymentToken.selector, eoa));
        new IPRoyaltyRegistry(eoa);
    }

    function test_Constructor_RevertsOnWrongDecimals() public {
        MockERC20 bad18 = new MockERC20("Bad", "BAD", 18);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidPaymentToken.selector, address(bad18)));
        new IPRoyaltyRegistry(address(bad18));
        MockERC20 bad0 = new MockERC20("Bad", "BAD", 0);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidPaymentToken.selector, address(bad0)));
        new IPRoyaltyRegistry(address(bad0));
    }

    function test_Constructor_RevertsOnCodeWithoutDecimals() public {
        // contract with code but no decimals(): the call reverts (bubbled, not InvalidPaymentToken)
        vm.expectRevert();
        new IPRoyaltyRegistry(address(this));
    }

    // ---- commitRegistration ----
    function test_Commit_StoresBlockAndEmits() public {
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.expectEmit(true, true, false, false, address(reg));
        emit IPRoyaltyRegistry.RegistrationCommitted(c, alice);
        vm.prank(alice);
        reg.commitRegistration(c);
        assertEq(reg.commitBlockOf(c), block.number);
    }

    function test_Commit_RevertsOnZero() public {
        vm.expectRevert(IPRoyaltyRegistry.ZeroCommitment.selector);
        reg.commitRegistration(bytes32(0));
    }

    function test_Commit_RevertsOnDuplicate() public {
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        reg.commitRegistration(c);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.CommitmentAlreadyExists.selector, c));
        reg.commitRegistration(c);
    }

    function test_Commitment_IsDeterministicAndOwnerBound() public view {
        assertEq(reg.registrationCommitment(alice, H1, SALT), keccak256(abi.encode(alice, H1, SALT)));
        assertTrue(reg.registrationCommitment(alice, H1, SALT) != reg.registrationCommitment(bob, H1, SALT));
    }

    // ---- registerAsset happy path ----
    function test_Register_HappyPath_StoresAllFieldsAndEmits() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, uint96(PRICE), true);
        r.kind = 4;
        r.createdAt = uint64(block.timestamp - 100);
        r.copyrightRef = keccak256("copyright");
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);

        vm.expectEmit(true, true, true, true, address(reg));
        emit IPRoyaltyRegistry.AssetRegistered(1, alice, H1, 4, "ipfs://meta", uint96(PRICE));
        vm.prank(alice);
        uint256 id = reg.registerAsset(r, SALT);

        assertEq(id, 1);
        assertEq(reg.assetCount(), 1);
        assertEq(reg.assetIdByHash(H1), 1);
        assertEq(reg.commitBlockOf(c), 0, "commitment consumed");

        IPRoyaltyRegistry.Asset memory a = reg.getAsset(1);
        assertEq(a.owner, alice);
        assertTrue(a.active);
        assertEq(a.pricePerUse, PRICE);
        assertEq(a.contentHash, H1);
        assertEq(a.uri, "ipfs://meta");
        assertEq(a.licenseUri, "ipfs://license");
        assertEq(a.kind, 4);
        assertEq(a.registeredAt, block.timestamp);
        assertEq(a.createdAt, block.timestamp - 100);
        assertTrue(a.transferable);
        assertEq(a.totalUses, 0);
        assertEq(a.totalEarned, 0);
        assertEq(a.unclaimed, 0);
        assertEq(a.copyrightRef, keccak256("copyright"));
        assertEq(a.noticeCount, 0);
    }

    function test_Register_IdsIncrement() public {
        assertEq(_registerSimple(alice, H1, 1, true), 1);
        assertEq(_registerSimple(bob, H2, 1, true), 2);
        assertEq(reg.assetCount(), 2);
    }

    function test_Register_AllowsZeroPriceEmptyLicenseAndCreatedAtNowOrZero() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 0, false);
        r.licenseUri = "";
        r.createdAt = uint64(block.timestamp);
        uint256 id = _register(alice, r);
        assertEq(reg.getAsset(id).pricePerUse, 0);
        assertEq(bytes(reg.getAsset(id).licenseUri).length, 0);
    }

    function test_Register_KindMaxAllowed() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.kind = 7;
        uint256 id = _register(alice, r);
        assertEq(reg.getAsset(id).kind, 7);
    }

    function test_Register_UriExactlyMaxAllowed() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.uri = _longStr(256);
        r.licenseUri = _longStr(256);
        uint256 id = _register(alice, r);
        assertEq(bytes(reg.getAsset(id).uri).length, 256);
        assertEq(bytes(reg.getAsset(id).licenseUri).length, 256);
    }

    // ---- commitment reverts ----
    function test_Register_RevertsCommitmentMissing() public {
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.CommitmentMissing.selector, c));
        reg.registerAsset(_reg(H1, 1, true), SALT);
    }

    function test_Register_RevertsCommitmentNotReady_SameBlock() public {
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(IPRoyaltyRegistry.CommitmentNotReady.selector, c, block.number, block.number)
        );
        reg.registerAsset(_reg(H1, 1, true), SALT);
    }

    function test_Register_CommitmentBoundToSender() public {
        // alice commits; bob (front-runner) cannot reveal with the same params
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        bytes32 bobC = reg.registrationCommitment(bob, H1, SALT);
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.CommitmentMissing.selector, bobC));
        reg.registerAsset(_reg(H1, 1, true), SALT);
        // alice still can
        vm.prank(alice);
        assertEq(reg.registerAsset(_reg(H1, 1, true), SALT), 1);
    }

    function test_Register_WrongSaltOrHashMissing() public {
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        bytes32 c1 = reg.registrationCommitment(alice, H1, keccak256("other"));
        bytes32 c2 = reg.registrationCommitment(alice, H2, SALT);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.CommitmentMissing.selector, c1));
        reg.registerAsset(_reg(H1, 1, true), keccak256("other"));
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.CommitmentMissing.selector, c2));
        reg.registerAsset(_reg(H2, 1, true), SALT);
    }

    function test_Register_CommitmentSingleUse() public {
        _registerSimple(alice, H1, 1, true);
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.CommitmentMissing.selector, c));
        reg.registerAsset(_reg(H1, 1, true), SALT);
    }

    function test_Register_CommitmentDoesNotExpire() public {
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1_000_000);
        skip(365 days);
        vm.prank(alice);
        assertEq(reg.registerAsset(_reg(H1, 1, true), SALT), 1);
    }

    // ---- validation reverts ----
    function test_Register_RevertsZeroContentHash() public {
        IPRoyaltyRegistry.Registration memory r = _reg(bytes32(0), 1, true);
        bytes32 c = reg.registrationCommitment(alice, bytes32(0), SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        vm.expectRevert(IPRoyaltyRegistry.ZeroContentHash.selector);
        reg.registerAsset(r, SALT);
    }

    function test_Register_RevertsDuplicateContentHash() public {
        _registerSimple(alice, H1, 1, true);
        // bob makes a fresh commitment on the same hash
        bytes32 c = reg.registrationCommitment(bob, H1, SALT);
        vm.prank(bob);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.ContentHashRegistered.selector, H1, uint256(1)));
        reg.registerAsset(_reg(H1, 1, true), SALT);
        assertEq(reg.assetCount(), 1);
    }

    function test_Register_RevertsInvalidKind() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.kind = 8;
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidKind.selector, uint8(8)));
        reg.registerAsset(r, SALT);
    }

    function testFuzz_Register_RevertsKindAboveMax(uint8 kind) public {
        kind = uint8(bound(kind, 8, 255));
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.kind = kind;
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidKind.selector, kind));
        reg.registerAsset(r, SALT);
    }

    function test_Register_RevertsEmptyUri() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.uri = "";
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidUriLength.selector, uint256(0)));
        reg.registerAsset(r, SALT);
    }

    function test_Register_RevertsUriTooLong() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.uri = _longStr(257);
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidUriLength.selector, uint256(257)));
        reg.registerAsset(r, SALT);
    }

    function test_Register_RevertsLicenseTooLong() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.licenseUri = _longStr(257);
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidUriLength.selector, uint256(257)));
        reg.registerAsset(r, SALT);
    }

    function test_Register_RevertsCreatedAtInFuture() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.createdAt = uint64(block.timestamp + 1);
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidCreatedAt.selector, r.createdAt));
        reg.registerAsset(r, SALT);
    }

    function test_Register_FailedRevealKeepsCommitment() public {
        IPRoyaltyRegistry.Registration memory r = _reg(H1, 1, true);
        r.kind = 9;
        bytes32 c = reg.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        vm.expectRevert();
        reg.registerAsset(r, SALT);
        assertGt(reg.commitBlockOf(c), 0, "revert rolls back commitment deletion");
    }
}
