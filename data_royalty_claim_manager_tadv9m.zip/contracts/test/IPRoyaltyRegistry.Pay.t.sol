// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IPRoyaltyRegistryTestBase} from "./IPRoyaltyRegistry.Base.t.sol";
import {IPRoyaltyRegistry} from "../IPRoyaltyRegistry.sol";
import {MockERC20} from "../test-helpers/MockERC20.sol";
import {Vm} from "forge-std/Vm.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/// @dev Fee-on-transfer token: delivers 1 unit less than requested on transfers.
contract FeeToken is MockERC20 {
    constructor() MockERC20("Fee", "FEE", 6) {}

    function _update(address from, address to, uint256 value) internal override {
        if (from != address(0) && to != address(0) && value > 0) {
            super._update(from, to, value - 1);
            super._update(from, address(0), 1);
        } else {
            super._update(from, to, value);
        }
    }
}

contract IPRoyaltyRegistryPayTest is IPRoyaltyRegistryTestBase {
    bytes32 internal constant H1 = keccak256("content1");
    bytes32 internal constant H2 = keccak256("content2");
    bytes32 internal constant REF = keccak256("usage-ref");
    uint256 internal id1;
    uint256 internal id2;

    function setUp() public override {
        super.setUp();
        id1 = _registerSimple(alice, H1, uint96(PRICE), true);
        id2 = _registerSimple(alice, H2, uint96(PRICE), false);
    }

    // ---- payForUsage ----
    function test_Pay_CreditsAndEmits() public {
        vm.expectEmit(true, true, false, true, address(reg));
        emit IPRoyaltyRegistry.UsagePaid(id1, payer, 3, 3 * PRICE, REF);
        vm.prank(payer);
        reg.payForUsage(id1, 3, PRICE, REF);

        IPRoyaltyRegistry.Asset memory a = reg.getAsset(id1);
        assertEq(a.totalUses, 3);
        assertEq(a.totalEarned, 3 * PRICE);
        assertEq(a.unclaimed, 3 * PRICE);
        assertEq(usdc.balanceOf(address(reg)), 3 * PRICE);
    }

    function test_Pay_PriceTooHigh() public {
        vm.prank(payer);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.PriceTooHigh.selector, PRICE, PRICE - 1));
        reg.payForUsage(id1, 1, PRICE - 1, REF);
    }

    function test_Pay_PriceFrontRunBySetPrice() public {
        vm.prank(alice);
        reg.setPrice(id1, uint96(PRICE * 2));
        vm.prank(payer);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.PriceTooHigh.selector, PRICE * 2, PRICE));
        reg.payForUsage(id1, 1, PRICE, REF);
    }

    function test_Pay_RevertsInactive() public {
        vm.prank(alice);
        reg.setActive(id1, false);
        vm.prank(payer);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetInactive.selector, id1));
        reg.payForUsage(id1, 1, PRICE, REF);
    }

    function test_Pay_RevertsZeroPrice() public {
        uint256 id = _registerSimple(bob, keccak256("free"), 0, true);
        vm.prank(payer);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.ZeroPrice.selector, id));
        reg.payForUsage(id, 1, type(uint256).max, REF);
    }

    function test_Pay_RevertsZeroUses() public {
        vm.prank(payer);
        vm.expectRevert(IPRoyaltyRegistry.ZeroUses.selector);
        reg.payForUsage(id1, 0, PRICE, REF);
    }

    function test_Pay_RevertsNonexistent() public {
        vm.prank(payer);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(77)));
        reg.payForUsage(77, 1, PRICE, REF);
    }

    function test_Pay_RevertsWithoutAllowanceOrBalance() public {
        vm.prank(bob); // no funds, no approval
        vm.expectRevert();
        reg.payForUsage(id1, 1, PRICE, REF);
    }

    function test_Pay_OverflowReverts() public {
        vm.prank(alice);
        reg.setPrice(id1, type(uint96).max);
        vm.prank(payer);
        vm.expectRevert(); // Panic(0x11) from checked price*uses
        reg.payForUsage(id1, type(uint256).max, type(uint256).max, REF);
    }

    function test_Pay_AnyoneIncludingOwnerCanPay() public {
        usdc.mint(alice, PRICE);
        vm.startPrank(alice);
        usdc.approve(address(reg), PRICE);
        reg.payForUsage(id1, 1, PRICE, REF);
        vm.stopPrank();
        assertEq(reg.claimable(id1), PRICE);
    }

    function test_Pay_RevertsOnFeeOnTransferToken() public {
        FeeToken ft = new FeeToken();
        IPRoyaltyRegistry r2 = new IPRoyaltyRegistry(address(ft));
        // register on r2
        bytes32 c = r2.registrationCommitment(alice, H1, SALT);
        vm.prank(alice);
        r2.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(alice);
        r2.registerAsset(_reg(H1, 100, true), SALT);

        ft.mint(payer, 1000);
        vm.startPrank(payer);
        ft.approve(address(r2), type(uint256).max);
        vm.expectRevert(); // UnexpectedReceivedAmount(100, 0, 99)
        r2.payForUsage(1, 1, 100, REF);
        vm.stopPrank();
    }

    function testFuzz_Pay_Accounting(uint96 price, uint64 uses, uint64 uses2) public {
        price = uint96(bound(price, 1, type(uint64).max));
        uses = uint64(bound(uses, 1, 1e6));
        uses2 = uint64(bound(uses2, 1, 1e6));
        vm.prank(alice);
        reg.setPrice(id1, price);
        uint256 total = uint256(price) * (uint256(uses) + uses2);
        usdc.mint(payer, total);

        uint256 balBefore = usdc.balanceOf(payer);
        vm.expectEmit(true, true, false, true, address(reg));
        emit IPRoyaltyRegistry.UsagePaid(id1, payer, uses, uint256(price) * uses, REF);
        vm.prank(payer);
        reg.payForUsage(id1, uses, price, REF);
        vm.prank(payer);
        reg.payForUsage(id1, uses2, price, REF);

        IPRoyaltyRegistry.Asset memory a = reg.getAsset(id1);
        assertEq(a.totalUses, uint256(uses) + uses2);
        assertEq(a.totalEarned, total);
        assertEq(a.unclaimed, total);
        assertEq(balBefore - usdc.balanceOf(payer), total);
        assertEq(usdc.balanceOf(address(reg)), total);
    }

    // ---- fundRoyalty ----
    function test_Fund_CreditsWithoutUses_AndEmits() public {
        vm.expectEmit(true, true, false, true, address(reg));
        emit IPRoyaltyRegistry.RoyaltyFunded(id1, payer, 123, REF);
        vm.prank(payer);
        reg.fundRoyalty(id1, 123, REF);
        IPRoyaltyRegistry.Asset memory a = reg.getAsset(id1);
        assertEq(a.totalUses, 0);
        assertEq(a.totalEarned, 123);
        assertEq(a.unclaimed, 123);
    }

    function test_Fund_WorksWithZeroPriceAsset() public {
        uint256 id = _registerSimple(bob, keccak256("free"), 0, true);
        vm.prank(payer);
        reg.fundRoyalty(id, 10, bytes32(0));
        assertEq(reg.claimable(id), 10);
    }

    function test_Fund_RevertsZeroAmount() public {
        vm.prank(payer);
        vm.expectRevert(IPRoyaltyRegistry.ZeroAmount.selector);
        reg.fundRoyalty(id1, 0, REF);
    }

    function test_Fund_RevertsInactive() public {
        vm.prank(alice);
        reg.setActive(id1, false);
        vm.prank(payer);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetInactive.selector, id1));
        reg.fundRoyalty(id1, 1, REF);
    }

    function test_Fund_RevertsNonexistent() public {
        vm.prank(payer);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(5)));
        reg.fundRoyalty(5, 1, REF);
    }

    function test_Fund_ReactivatedAssetAcceptsPaymentAgain() public {
        vm.startPrank(alice);
        reg.setActive(id1, false);
        reg.setActive(id1, true);
        vm.stopPrank();
        vm.prank(payer);
        reg.fundRoyalty(id1, 7, REF);
        assertEq(reg.claimable(id1), 7);
    }

    // ---- claim ----
    function test_Claim_PaysOwnerAndEmits() public {
        _pay(id1, 4);
        vm.expectEmit(true, true, false, true, address(reg));
        emit IPRoyaltyRegistry.RoyaltyClaimed(id1, alice, 4 * PRICE);
        vm.prank(alice);
        uint256 amt = reg.claim(id1);
        assertEq(amt, 4 * PRICE);
        assertEq(usdc.balanceOf(alice), 4 * PRICE);
        assertEq(reg.claimable(id1), 0);
        assertEq(reg.getAsset(id1).totalEarned, 4 * PRICE, "lifetime earned retained");
        assertEq(usdc.balanceOf(address(reg)), 0);
    }

    function test_Claim_EmitsRoyaltyClaimedBeforeTokenTransfer() public {
        _pay(id1, 2);
        vm.recordLogs();
        vm.prank(alice);
        reg.claim(id1);
        Vm.Log[] memory logs = vm.getRecordedLogs();
        int256 claimedIdx = -1;
        int256 transferIdx = -1;
        for (uint256 i = 0; i < logs.length; i++) {
            if (logs[i].emitter == address(reg) && logs[i].topics[0] == IPRoyaltyRegistry.RoyaltyClaimed.selector) {
                claimedIdx = int256(i);
            } else if (logs[i].emitter == address(usdc) && logs[i].topics[0] == IERC20.Transfer.selector) {
                transferIdx = int256(i);
            }
        }
        assertGe(claimedIdx, 0, "RoyaltyClaimed emitted");
        assertGe(transferIdx, 0, "Transfer emitted");
        assertLt(claimedIdx, transferIdx, "RoyaltyClaimed precedes token transfer");
        assertEq(abi.decode(logs[uint256(claimedIdx)].data, (uint256)), 2 * PRICE);
        assertEq(usdc.balanceOf(alice), 2 * PRICE);
    }

    function test_Claim_RevertsNothingToClaim() public {
        vm.prank(alice);
        vm.expectRevert(IPRoyaltyRegistry.NothingToClaim.selector);
        reg.claim(id1);
    }

    function test_Claim_RevertsSecondClaim() public {
        _pay(id1, 1);
        vm.startPrank(alice);
        reg.claim(id1);
        vm.expectRevert(IPRoyaltyRegistry.NothingToClaim.selector);
        reg.claim(id1);
        vm.stopPrank();
    }

    function test_Claim_RevertsNonOwner() public {
        _pay(id1, 1);
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotAssetOwner.selector, id1, bob));
        reg.claim(id1);
    }

    function test_Claim_RevertsNonexistent() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(9)));
        reg.claim(9);
    }

    function test_Claim_StillWorksAfterSetActiveFalse() public {
        _pay(id1, 2);
        vm.startPrank(alice);
        reg.setActive(id1, false);
        assertEq(reg.claim(id1), 2 * PRICE);
        vm.stopPrank();
        assertEq(usdc.balanceOf(alice), 2 * PRICE);
    }

    function testFuzz_Claim_AccountingExact(uint96 price, uint32 uses, uint128 funded) public {
        price = uint96(bound(price, 1, type(uint64).max));
        uses = uint32(bound(uses, 1, type(uint32).max));
        funded = uint128(bound(funded, 1, type(uint120).max));
        vm.prank(alice);
        reg.setPrice(id1, price);
        uint256 expected = uint256(price) * uses + funded;
        usdc.mint(payer, expected);

        vm.startPrank(payer);
        reg.payForUsage(id1, uses, price, REF);
        reg.fundRoyalty(id1, funded, REF);
        vm.stopPrank();
        assertEq(reg.claimable(id1), expected);
        assertEq(usdc.balanceOf(address(reg)), expected);

        vm.prank(alice);
        assertEq(reg.claim(id1), expected);
        assertEq(usdc.balanceOf(alice), expected);
        assertEq(usdc.balanceOf(address(reg)), 0);
        assertEq(reg.claimable(id1), 0);
    }

    // ---- claimMany ----
    function test_ClaimMany_AggregatesAndEmitsPerEntry() public {
        _pay(id1, 1);
        _pay(id2, 2);
        uint256[] memory ids = new uint256[](2);
        ids[0] = id1;
        ids[1] = id2;
        vm.expectEmit(true, true, false, true, address(reg));
        emit IPRoyaltyRegistry.RoyaltyClaimed(id1, alice, PRICE);
        vm.expectEmit(true, true, false, true, address(reg));
        emit IPRoyaltyRegistry.RoyaltyClaimed(id2, alice, 2 * PRICE);
        vm.prank(alice);
        assertEq(reg.claimMany(ids), 3 * PRICE);
        assertEq(usdc.balanceOf(alice), 3 * PRICE);
        assertEq(reg.claimable(id1), 0);
        assertEq(reg.claimable(id2), 0);
    }

    function test_ClaimMany_ZeroBalanceEntryEmitsZero() public {
        _pay(id1, 1);
        uint256[] memory ids = new uint256[](2);
        ids[0] = id1;
        ids[1] = id2; // zero balance
        vm.expectEmit(true, true, false, true, address(reg));
        emit IPRoyaltyRegistry.RoyaltyClaimed(id2, alice, 0);
        vm.prank(alice);
        // events are ordered: id1 first then id2; expectEmit matches in order, so
        // assert via the return value as well
        reg.claimMany(ids);
    }

    function test_ClaimMany_DuplicateIdsPaidOnce() public {
        _pay(id1, 2);
        uint256[] memory ids = new uint256[](3);
        ids[0] = id1;
        ids[1] = id1;
        ids[2] = id1;
        vm.prank(alice);
        assertEq(reg.claimMany(ids), 2 * PRICE);
        assertEq(usdc.balanceOf(alice), 2 * PRICE);
    }

    function test_ClaimMany_RevertsEmpty() public {
        uint256[] memory ids = new uint256[](0);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidBatchLength.selector, uint256(0)));
        reg.claimMany(ids);
    }

    function test_ClaimMany_RevertsOver50() public {
        uint256[] memory ids = new uint256[](51);
        for (uint256 i = 0; i < 51; i++) {
            ids[i] = id1;
        }
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidBatchLength.selector, uint256(51)));
        reg.claimMany(ids);
    }

    function test_ClaimMany_Exactly50Allowed() public {
        _pay(id1, 1);
        uint256[] memory ids = new uint256[](50);
        for (uint256 i = 0; i < 50; i++) {
            ids[i] = id1;
        }
        vm.prank(alice);
        assertEq(reg.claimMany(ids), PRICE);
    }

    function test_ClaimMany_RevertsNothingToClaimAggregate() public {
        uint256[] memory ids = new uint256[](2);
        ids[0] = id1;
        ids[1] = id2;
        vm.prank(alice);
        vm.expectRevert(IPRoyaltyRegistry.NothingToClaim.selector);
        reg.claimMany(ids);
    }

    function test_ClaimMany_RevertsIfAnyIdNotOwned_Atomic() public {
        uint256 idBob = _registerSimple(bob, keccak256("bobs"), uint96(PRICE), true);
        _pay(id1, 1);
        uint256[] memory ids = new uint256[](2);
        ids[0] = id1;
        ids[1] = idBob;
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotAssetOwner.selector, idBob, alice));
        reg.claimMany(ids);
        assertEq(reg.claimable(id1), PRICE, "atomic: first entry not drained");
    }

    function test_ClaimMany_RevertsNonexistentId() public {
        uint256[] memory ids = new uint256[](1);
        ids[0] = 500;
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(500)));
        reg.claimMany(ids);
    }

    function test_ClaimMany_InactiveAssetsClaimable() public {
        _pay(id1, 1);
        vm.startPrank(alice);
        reg.setActive(id1, false);
        uint256[] memory ids = new uint256[](1);
        ids[0] = id1;
        assertEq(reg.claimMany(ids), PRICE);
        vm.stopPrank();
    }
}
