// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IPRoyaltyRegistryTestBase} from "./IPRoyaltyRegistry.Base.t.sol";
import {IPRoyaltyRegistry} from "../IPRoyaltyRegistry.sol";

contract IPRoyaltyRegistryOwnerTest is IPRoyaltyRegistryTestBase {
    bytes32 internal constant H1 = keccak256("content1");
    bytes32 internal constant H2 = keccak256("content2");
    uint256 internal tid; // transferable asset owned by alice
    uint256 internal sid; // soulbound asset owned by alice

    function setUp() public override {
        super.setUp();
        tid = _registerSimple(alice, H1, uint96(PRICE), true);
        sid = _registerSimple(alice, H2, uint96(PRICE), false);
    }

    // ---- setPrice ----
    function test_SetPrice_UpdatesAndEmits() public {
        vm.expectEmit(true, false, false, true, address(reg));
        emit IPRoyaltyRegistry.PriceUpdated(tid, uint96(PRICE), 9e6);
        vm.prank(alice);
        reg.setPrice(tid, 9e6);
        assertEq(reg.getAsset(tid).pricePerUse, 9e6);
    }

    function test_SetPrice_ToZeroDisablesPayForUsage() public {
        vm.prank(alice);
        reg.setPrice(tid, 0);
        vm.prank(payer);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.ZeroPrice.selector, tid));
        reg.payForUsage(tid, 1, 1e6, bytes32(0));
    }

    function test_SetPrice_RevertsNonOwner() public {
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotAssetOwner.selector, tid, bob));
        reg.setPrice(tid, 1);
    }

    function test_SetPrice_RevertsNonexistent() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(99)));
        reg.setPrice(99, 1);
    }

    function test_SetPrice_DoesNotChangeUnclaimed() public {
        _pay(tid, 2);
        vm.prank(alice);
        reg.setPrice(tid, 1);
        assertEq(reg.claimable(tid), 2 * PRICE);
    }

    // ---- setActive ----
    function test_SetActive_TogglesAndEmits() public {
        vm.expectEmit(true, false, false, true, address(reg));
        emit IPRoyaltyRegistry.ActiveUpdated(tid, false);
        vm.prank(alice);
        reg.setActive(tid, false);
        assertFalse(reg.getAsset(tid).active);

        vm.prank(alice);
        reg.setActive(tid, true);
        assertTrue(reg.getAsset(tid).active);
    }

    function test_SetActive_RevertsNonOwner() public {
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotAssetOwner.selector, tid, bob));
        reg.setActive(tid, false);
    }

    // ---- transferAsset ----
    function test_Transfer_TransferableMovesOwnerAndUnclaimed() public {
        _pay(tid, 3);
        vm.expectEmit(true, true, true, false, address(reg));
        emit IPRoyaltyRegistry.AssetTransferred(tid, alice, bob);
        vm.prank(alice);
        reg.transferAsset(tid, bob);
        assertEq(reg.getAsset(tid).owner, bob);
        assertEq(reg.claimable(tid), 3 * PRICE);

        // old owner loses control, new owner can claim
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotAssetOwner.selector, tid, alice));
        reg.claim(tid);
        vm.prank(bob);
        assertEq(reg.claim(tid), 3 * PRICE);
        assertEq(usdc.balanceOf(bob), 3 * PRICE);
    }

    function test_Transfer_NonTransferableReverts() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotTransferable.selector, sid));
        reg.transferAsset(sid, bob);
        assertEq(reg.getAsset(sid).owner, alice);
    }

    function test_Transfer_RevertsZeroAddress() public {
        vm.prank(alice);
        vm.expectRevert(IPRoyaltyRegistry.ZeroAddress.selector);
        reg.transferAsset(tid, address(0));
    }

    function test_Transfer_RevertsNonOwner() public {
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotAssetOwner.selector, tid, bob));
        reg.transferAsset(tid, bob);
    }

    function test_Transfer_NewOwnerCanAdminister() public {
        vm.prank(alice);
        reg.transferAsset(tid, bob);
        vm.prank(bob);
        reg.setPrice(tid, 1);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotAssetOwner.selector, tid, alice));
        reg.setPrice(tid, 2);
    }

    // ---- recordNotice ----
    function test_Notice_RecordsEmitsAndCounts() public {
        bytes32 ev = keccak256("evidence");
        vm.expectEmit(true, true, false, true, address(reg));
        emit IPRoyaltyRegistry.UnauthorizedUseNoticed(tid, 1, ev, "ipfs://n", uint64(block.timestamp));
        vm.prank(alice);
        assertEq(reg.recordNotice(tid, ev, "ipfs://n"), 1);
        assertEq(reg.getAsset(tid).noticeCount, 1);

        vm.prank(alice);
        assertEq(reg.recordNotice(tid, ev, ""), 2);
        assertEq(reg.getAsset(tid).noticeCount, 2);
        assertEq(reg.getAsset(sid).noticeCount, 0, "per-asset counter");
    }

    function test_Notice_RevertsZeroEvidence() public {
        vm.prank(alice);
        vm.expectRevert(IPRoyaltyRegistry.ZeroEvidenceHash.selector);
        reg.recordNotice(tid, bytes32(0), "x");
    }

    function test_Notice_RevertsLongUri() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.InvalidUriLength.selector, uint256(257)));
        reg.recordNotice(tid, keccak256("e"), _longStr(257));
        assertEq(reg.getAsset(tid).noticeCount, 0);
    }

    function test_Notice_MaxLengthUriAllowed() public {
        vm.prank(alice);
        assertEq(reg.recordNotice(tid, keccak256("e"), _longStr(256)), 1);
    }

    function test_Notice_RevertsNonOwner() public {
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.NotAssetOwner.selector, tid, bob));
        reg.recordNotice(tid, keccak256("e"), "");
    }

    function test_Notice_WorksWhenInactiveAndNonTransferable() public {
        vm.startPrank(alice);
        reg.setActive(sid, false);
        assertEq(reg.recordNotice(sid, keccak256("e"), "u"), 1);
        vm.stopPrank();
    }

    function test_Notice_RevertsNonexistent() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(42)));
        reg.recordNotice(42, keccak256("e"), "");
    }

    // ---- views ----
    function test_GetAsset_RevertsNonexistentAndZero() public {
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(0)));
        reg.getAsset(0);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(3)));
        reg.getAsset(3);
        vm.expectRevert(abi.encodeWithSelector(IPRoyaltyRegistry.AssetNotFound.selector, uint256(3)));
        reg.claimable(3);
    }

    // ---- getAssets paging ----
    function test_GetAssets_RevertsStartZero() public {
        vm.expectRevert(IPRoyaltyRegistry.InvalidStart.selector);
        reg.getAssets(0, 10);
    }

    function test_GetAssets_BasicPage() public view {
        (IPRoyaltyRegistry.Asset[] memory a, uint256[] memory ids) = reg.getAssets(1, 10);
        assertEq(a.length, 2);
        assertEq(ids.length, 2);
        assertEq(ids[0], 1);
        assertEq(ids[1], 2);
        assertEq(a[0].contentHash, H1);
        assertEq(a[1].contentHash, H2);
    }

    function test_GetAssets_ZeroLimitEmpty() public view {
        (IPRoyaltyRegistry.Asset[] memory a, uint256[] memory ids) = reg.getAssets(1, 0);
        assertEq(a.length, 0);
        assertEq(ids.length, 0);
    }

    function test_GetAssets_StartBeyondCountEmpty() public view {
        (IPRoyaltyRegistry.Asset[] memory a,) = reg.getAssets(3, 10);
        assertEq(a.length, 0);
        (a,) = reg.getAssets(type(uint256).max, type(uint256).max);
        assertEq(a.length, 0);
    }

    function test_GetAssets_PartialAndOffset() public view {
        (IPRoyaltyRegistry.Asset[] memory a, uint256[] memory ids) = reg.getAssets(2, 5);
        assertEq(a.length, 1);
        assertEq(ids[0], 2);
        assertEq(a[0].contentHash, H2);
        (a, ids) = reg.getAssets(1, 1);
        assertEq(a.length, 1);
        assertEq(ids[0], 1);
    }

    function test_GetAssets_CapsAtMaxPageSize() public {
        for (uint256 i = 0; i < 110; i++) {
            _registerSimple(bob, keccak256(abi.encode("bulk", i)), 1, true);
        }
        assertEq(reg.assetCount(), 112);
        (IPRoyaltyRegistry.Asset[] memory a, uint256[] memory ids) = reg.getAssets(1, 1000);
        assertEq(a.length, 100);
        assertEq(ids[99], 100);
        (a, ids) = reg.getAssets(101, 1000);
        assertEq(a.length, 12);
        assertEq(ids[11], 112);
        (a,) = reg.getAssets(1, 100);
        assertEq(a.length, 100);
    }
}
