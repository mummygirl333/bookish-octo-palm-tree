// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IPRoyaltyRegistryTestBase} from "./IPRoyaltyRegistry.Base.t.sol";
import {IPRoyaltyRegistry} from "../IPRoyaltyRegistry.sol";
import {MockERC20} from "../test-helpers/MockERC20.sol";
import {Test} from "forge-std/Test.sol";

contract IPRoyaltyHandler is Test {
    IPRoyaltyRegistry public reg;
    MockERC20 public usdc;
    address[] public actors;
    address public payer = address(0xBEEF);
    uint256 public nAssets;

    uint256 public ghostPaid;
    uint256 public ghostClaimed;

    constructor(IPRoyaltyRegistry r, MockERC20 u) {
        reg = r;
        usdc = u;
        actors.push(address(0xA1));
        actors.push(address(0xA2));
        actors.push(address(0xA3));
        u.mint(payer, type(uint128).max);
        vm.prank(payer);
        u.approve(address(r), type(uint256).max);
    }

    function register(uint256 actorSeed, uint96 price, bool transferable) external {
        address who = actors[actorSeed % actors.length];
        bytes32 h = keccak256(abi.encode("h", nAssets));
        IPRoyaltyRegistry.Registration memory rg = IPRoyaltyRegistry.Registration({
            kind: 0,
            uri: "u",
            licenseUri: "",
            contentHash: h,
            pricePerUse: uint96(bound(price, 0, 1e9)),
            createdAt: 0,
            transferable: transferable,
            copyrightRef: bytes32(0)
        });
        bytes32 c = reg.registrationCommitment(who, h, bytes32(0));
        vm.prank(who);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(who);
        reg.registerAsset(rg, bytes32(0));
        nAssets++;
    }

    function pay(uint256 idSeed, uint256 uses) external {
        if (nAssets == 0) return;
        uint256 id = (idSeed % nAssets) + 1;
        uses = bound(uses, 1, 1e6);
        IPRoyaltyRegistry.Asset memory a = reg.getAsset(id);
        if (!a.active || a.pricePerUse == 0) return;
        vm.prank(payer);
        reg.payForUsage(id, uses, type(uint256).max, bytes32(0));
        ghostPaid += uint256(a.pricePerUse) * uses;
    }

    function fund(uint256 idSeed, uint256 amount) external {
        if (nAssets == 0) return;
        uint256 id = (idSeed % nAssets) + 1;
        amount = bound(amount, 1, 1e12);
        if (!reg.getAsset(id).active) return;
        vm.prank(payer);
        reg.fundRoyalty(id, amount, bytes32(0));
        ghostPaid += amount;
    }

    function claim(uint256 idSeed) external {
        if (nAssets == 0) return;
        uint256 id = (idSeed % nAssets) + 1;
        uint256 owed = reg.claimable(id);
        if (owed == 0) return;
        address o = reg.getAsset(id).owner;
        vm.prank(o);
        ghostClaimed += reg.claim(id);
    }

    function toggleActive(uint256 idSeed, bool active) external {
        if (nAssets == 0) return;
        uint256 id = (idSeed % nAssets) + 1;
        vm.prank(reg.getAsset(id).owner);
        reg.setActive(id, active);
    }

    function setPrice(uint256 idSeed, uint96 price) external {
        if (nAssets == 0) return;
        uint256 id = (idSeed % nAssets) + 1;
        vm.prank(reg.getAsset(id).owner);
        reg.setPrice(id, uint96(bound(price, 0, 1e9)));
    }

    function transfer(uint256 idSeed, uint256 toSeed) external {
        if (nAssets == 0) return;
        uint256 id = (idSeed % nAssets) + 1;
        IPRoyaltyRegistry.Asset memory a = reg.getAsset(id);
        if (!a.transferable) return;
        vm.prank(a.owner);
        reg.transferAsset(id, actors[toSeed % actors.length]);
    }

    function claimMany(uint256 seedA, uint256 seedB) external {
        if (nAssets == 0) return;
        address o = actors[seedA % actors.length];
        uint256[] memory tmp = new uint256[](nAssets > 50 ? 50 : nAssets);
        uint256 n;
        for (uint256 i = 1; i <= nAssets && n < tmp.length; i++) {
            if (reg.getAsset(i).owner == o && (i + (seedB % 2)) % 2 == 0) tmp[n++] = i;
        }
        if (n == 0) return;
        uint256[] memory ids = new uint256[](n);
        uint256 owed;
        for (uint256 i = 0; i < n; i++) {
            ids[i] = tmp[i];
            owed += reg.claimable(tmp[i]);
        }
        if (owed == 0) return;
        vm.prank(o);
        ghostClaimed += reg.claimMany(ids);
    }

    function sumUnclaimed() external view returns (uint256 s) {
        for (uint256 i = 1; i <= nAssets; i++) {
            s += reg.claimable(i);
        }
    }

    function sumEarned() external view returns (uint256 s) {
        for (uint256 i = 1; i <= nAssets; i++) {
            s += reg.getAsset(i).totalEarned;
        }
    }
}

contract IPRoyaltyRegistryInvariantTest is IPRoyaltyRegistryTestBase {
    IPRoyaltyHandler internal handler;

    function setUp() public override {
        super.setUp();
        handler = new IPRoyaltyHandler(reg, usdc);
        targetContract(address(handler));
        bytes4[] memory sel = new bytes4[](8);
        sel[0] = handler.register.selector;
        sel[1] = handler.pay.selector;
        sel[2] = handler.fund.selector;
        sel[3] = handler.claim.selector;
        sel[4] = handler.toggleActive.selector;
        sel[5] = handler.setPrice.selector;
        sel[6] = handler.transfer.selector;
        sel[7] = handler.claimMany.selector;
        targetSelector(FuzzSelector({addr: address(handler), selectors: sel}));
    }

    /// Sum of unclaimed across all assets never exceeds the registry's USDC balance.
    function invariant_UnclaimedNeverExceedsBalance() public view {
        assertLe(handler.sumUnclaimed(), usdc.balanceOf(address(reg)));
    }

    /// With no stray transfers, balance equals exactly paid - claimed.
    function invariant_BalanceEqualsPaidMinusClaimed() public view {
        assertEq(usdc.balanceOf(address(reg)), handler.ghostPaid() - handler.ghostClaimed());
        assertEq(handler.sumUnclaimed(), handler.ghostPaid() - handler.ghostClaimed());
    }

    /// Lifetime earned across assets equals total ever paid.
    function invariant_EarnedEqualsPaid() public view {
        assertEq(handler.sumEarned(), handler.ghostPaid());
    }

    function invariant_AssetCountMatchesHandler() public view {
        assertEq(reg.assetCount(), handler.nAssets());
    }
}
