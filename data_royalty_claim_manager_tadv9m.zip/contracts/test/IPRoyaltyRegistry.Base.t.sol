// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {IPRoyaltyRegistry} from "../IPRoyaltyRegistry.sol";
import {MockERC20} from "../test-helpers/MockERC20.sol";

abstract contract IPRoyaltyRegistryTestBase is Test {
    IPRoyaltyRegistry internal reg;
    MockERC20 internal usdc;

    address internal alice = makeAddr("alice");
    address internal bob = makeAddr("bob");
    address internal payer = makeAddr("payer");

    uint256 internal constant PRICE = 5e6;
    bytes32 internal constant SALT = keccak256("salt");

    function setUp() public virtual {
        vm.warp(1_700_000_000);
        usdc = new MockERC20("Mock USDC", "mUSDC", 6);
        reg = new IPRoyaltyRegistry(address(usdc));
        usdc.mint(payer, 1_000_000_000e6);
        vm.prank(payer);
        usdc.approve(address(reg), type(uint256).max);
    }

    function _reg(bytes32 h, uint96 price, bool transferable)
        internal
        pure
        returns (IPRoyaltyRegistry.Registration memory r)
    {
        r = IPRoyaltyRegistry.Registration({
            kind: 1,
            uri: "ipfs://meta",
            licenseUri: "ipfs://license",
            contentHash: h,
            pricePerUse: price,
            createdAt: 0,
            transferable: transferable,
            copyrightRef: bytes32(0)
        });
    }

    /// @dev commit, advance one block, reveal. Returns new asset id.
    function _register(address who, IPRoyaltyRegistry.Registration memory r) internal returns (uint256 id) {
        bytes32 c = reg.registrationCommitment(who, r.contentHash, SALT);
        vm.prank(who);
        reg.commitRegistration(c);
        vm.roll(block.number + 1);
        vm.prank(who);
        id = reg.registerAsset(r, SALT);
    }

    function _registerSimple(address who, bytes32 h, uint96 price, bool transferable) internal returns (uint256) {
        return _register(who, _reg(h, price, transferable));
    }

    function _pay(uint256 id, uint256 uses) internal {
        vm.prank(payer);
        reg.payForUsage(id, uses, type(uint256).max, bytes32(0));
    }

    function _bytesOfLen(uint256 n) internal pure returns (string memory) {
        return string(new bytes(n));
    }

    function _longStr(uint256 n) internal pure returns (string memory) {
        bytes memory b = new bytes(n);
        for (uint256 i = 0; i < n; i++) {
            b[i] = "a";
        }
        return string(b);
    }
}
