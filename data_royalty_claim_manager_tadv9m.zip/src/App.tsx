import { useState } from 'react'
import { useAccount } from 'wagmi'
import { ConnectKitButton } from 'connectkit'
import { TriangleAlert } from 'lucide-react'
import { REGISTRY_ADDRESS, type AssetView } from '@/contracts/registry'
import { useAssets } from '@/hooks/useAssets'
import { usePending, type PendingRegistration } from '@/hooks/usePending'
import { MyDataView } from '@/components/MyDataView'
import { PaySheet } from '@/components/PaySheet'
import { RegisterSheet } from '@/components/RegisterSheet'
import { RegistryView } from '@/components/RegistryView'
import { VaultView } from '@/components/VaultView'
import type { Hex } from 'viem'

type Tab = 'registry' | 'mine' | 'vault'

export default function App() {
  const { address } = useAccount()
  const { assets, total, isLoading, isError } = useAssets()
  const { pending, add, remove } = usePending(address)
  const [tab, setTab] = useState<Tab>('mine')
  const [paying, setPaying] = useState<AssetView | null>(null)
  const [registerOpen, setRegisterOpen] = useState(false)
  const [resume, setResume] = useState<PendingRegistration | null>(null)
  const [prefill, setPrefill] = useState<{ contentHash: Hex; label: string } | null>(null)

  const openRegister = (entry: PendingRegistration | null) => {
    setResume(entry)
    setPrefill(null)
    setRegisterOpen(true)
  }

  const registerFromVault = (contentHash: Hex, label: string) => {
    setResume(null)
    setPrefill({ contentHash, label })
    setTab('mine')
    setRegisterOpen(true)
  }

  return (
    <div className="mx-auto min-h-dvh w-full max-w-xl px-4 pb-24 pt-6">
      <header className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="display text-2xl font-bold text-balance">Data Royalty Claim Manager</h1>
          <p className="text-xs" style={{ color: 'var(--muted)' }}>
            Get paid in USDC when others use your work
          </p>
        </div>
        <ConnectKitButton showBalance={false} />
      </header>

      {!REGISTRY_ADDRESS && (
        <div
          className="mb-4 flex items-start gap-3 rounded-2xl p-4 text-sm"
          style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--danger)' }}
        >
          <TriangleAlert className="mt-0.5 size-4 shrink-0" />
          <p className="text-pretty">
            The royalty registry contract is not deployed yet, so nothing can be registered or paid. Deploy it to Arc
            Testnet to turn this app on.
          </p>
        </div>
      )}

      <nav
        className="mb-4 grid grid-cols-3 gap-1 rounded-2xl p-1 glass-card"
        role="tablist"
        aria-label="Sections"
      >
        {(
          [
            ['mine', 'My IP'],
            ['registry', `Registry${total > 0n ? ` (${total.toString()})` : ''}`],
            ['vault', 'Vault'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            role="tab"
            aria-selected={tab === id}
            onClick={() => setTab(id)}
            className="min-h-11 rounded-xl text-sm font-semibold transition-colors"
            style={tab === id ? { background: 'var(--accent)', color: '#fff' } : { color: 'var(--muted)' }}
          >
            {label}
          </button>
        ))}
      </nav>

      {isError && (
        <p className="mb-3 text-xs" style={{ color: 'var(--danger)' }}>
          Could not load the registry. Check your connection and refresh.
        </p>
      )}

      {tab === 'vault' ? (
        <VaultView onRegister={registerFromVault} />
      ) : tab === 'mine' ? (
        <MyDataView
          assets={assets}
          pending={pending}
          onRegister={() => openRegister(null)}
          onResume={(entry) => openRegister(entry)}
        />
      ) : (
        <RegistryView assets={assets} isLoading={isLoading} onPay={setPaying} />
      )}

      <PaySheet asset={paying} onClose={() => setPaying(null)} />
      <RegisterSheet
        open={registerOpen}
        onClose={() => setRegisterOpen(false)}
        resume={resume}
        prefill={prefill}
        onCommitted={add}
        onFinished={remove}
      />
    </div>
  )
}
