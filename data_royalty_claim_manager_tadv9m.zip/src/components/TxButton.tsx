import type { ReactNode } from 'react'
import { useAccount } from 'wagmi'
import { useModal } from 'connectkit'
import { ExternalLink, Loader2 } from 'lucide-react'
import { CHAIN, CHAIN_ID } from '@/contracts/registry'
import { txUrl } from '@/lib/format'
import type { SendStatus } from '@/hooks/useSend'

interface TxButtonProps {
  label: ReactNode
  onClick: () => void | Promise<void>
  status: SendStatus
  disabled?: boolean
  variant?: 'primary' | 'ghost'
  className?: string
}

export function TxButton({ label, onClick, status, disabled, variant = 'primary', className = '' }: TxButtonProps) {
  const { isConnected, chainId } = useAccount()
  const { setOpen } = useModal()
  const wrongChain = isConnected && chainId !== CHAIN_ID

  const base =
    'flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold transition-all disabled:cursor-not-allowed disabled:opacity-40 hover:scale-[1.01] active:scale-[0.99]'
  const style =
    variant === 'primary'
      ? { background: 'var(--accent)', color: '#fff' }
      : { background: 'var(--surface-strong)', color: 'var(--ink)', border: '1px solid var(--border)' }

  if (!isConnected) {
    return (
      <button className={`${base} ${className}`} style={style} onClick={() => setOpen(true)}>
        Connect wallet
      </button>
    )
  }

  return (
    <button
      className={`${base} ${className}`}
      style={style}
      disabled={disabled || status === 'wallet' || status === 'confirming'}
      onClick={() => {
        void onClick()
      }}
    >
      {status === 'wallet' ? (
        <>
          <Loader2 className="size-4 animate-spin" /> Confirm in wallet...
        </>
      ) : status === 'confirming' ? (
        <>
          <Loader2 className="size-4 animate-spin" /> Confirming...
        </>
      ) : wrongChain ? (
        `Switch to ${CHAIN.name} and continue`
      ) : (
        label
      )}
    </button>
  )
}

export function TxReceipt({ status, hash, error }: { status: SendStatus; hash?: string; error?: string }) {
  if (status === 'error' && error) {
    return (
      <p className="mt-3 rounded-xl px-3 py-2 text-xs" style={{ color: 'var(--danger)', background: 'rgba(186,43,76,0.08)' }}>
        {error}
      </p>
    )
  }
  if (status === 'success' && hash) {
    return (
      <div className="mt-3 rounded-xl px-3 py-2 text-xs glass-inner">
        <span className="font-semibold" style={{ color: 'var(--success)' }}>
          Confirmed
        </span>
        <a
          href={txUrl(hash)}
          target="_blank"
          rel="noopener noreferrer"
          className="ml-2 inline-flex items-center gap-1 underline"
          style={{ color: 'var(--accent-hover)' }}
        >
          View on explorer <ExternalLink className="size-3" />
        </a>
      </div>
    )
  }
  return null
}
