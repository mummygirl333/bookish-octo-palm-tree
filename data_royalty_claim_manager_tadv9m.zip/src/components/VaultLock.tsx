import { useState } from 'react'
import { toast } from 'sonner'
import { Eye, EyeOff, Fingerprint, KeyRound, Loader2, LockKeyhole, Upload } from 'lucide-react'
import { BiometricError, biometricSupported, unlockBiometric } from '@/lib/biometric'
import { generateRecoveryKey } from '@/lib/recoveryKey'
import {
  adoptFromCopy,
  createProfile,
  MIN_PASSPHRASE,
  unlockWithPasskey,
  unlockWithRecovery,
  VaultError,
  type Profile,
} from '@/lib/vaultCrypto'
import { saveProfile } from '@/lib/vaultProfile'

interface VaultLockProps {
  profile: Profile | null
  onUnlocked: (profile: Profile, key: CryptoKey) => void
}

export function VaultLock({ profile, onUnlocked }: VaultLockProps) {
  const [recoveryKey, setRecoveryKey] = useState('')
  const [show, setShow] = useState(false)
  const [written, setWritten] = useState(false)
  const [generated, setGenerated] = useState(false)
  const [busy, setBusy] = useState(false)

  const longEnough = recoveryKey.length >= MIN_PASSPHRASE
  const canBiometric = !!profile?.passkey && !!profile.credentialId && !!profile.prfSalt && biometricSupported()

  const guard = async (work: () => Promise<void>) => {
    setBusy(true)
    try {
      await work()
    } catch (err) {
      toast.error(
        err instanceof VaultError || err instanceof BiometricError ? err.message : 'That did not work. Please try again.',
      )
    } finally {
      setBusy(false)
    }
  }

  const generate = () => {
    setRecoveryKey(generateRecoveryKey())
    setShow(true)
    setGenerated(true)
    setWritten(false)
  }

  const create = () =>
    void guard(async () => {
      const made = await createProfile(recoveryKey)
      saveProfile(made.profile)
      setRecoveryKey('')
      onUnlocked(made.profile, made.key)
      toast.success('Vault created. Add fingerprint or face unlock next.')
    })

  const unlockRecovery = () =>
    void guard(async () => {
      if (!profile) return
      const key = await unlockWithRecovery(profile, recoveryKey)
      setRecoveryKey('')
      onUnlocked(profile, key)
    })

  const unlockBio = () =>
    void guard(async () => {
      if (!profile?.credentialId || !profile.prfSalt) return
      const secret = await unlockBiometric(profile.credentialId, profile.prfSalt)
      onUnlocked(profile, await unlockWithPasskey(profile, secret))
    })

  const restore = (file: File | undefined) => {
    if (!file) return
    void guard(async () => {
      const adopted = await adoptFromCopy(file, recoveryKey)
      saveProfile(adopted.profile)
      setRecoveryKey('')
      onUnlocked(adopted.profile, adopted.key)
      toast.success('Vault restored on this device. Add your encrypted copies back with Restore.')
    })
  }

  const keyField = (
    <div className="field flex items-center gap-2 rounded-2xl px-3 glass-inner">
      <input
        type={show ? 'text' : 'password'}
        value={recoveryKey}
        onChange={(e) => {
          setRecoveryKey(e.target.value)
          setGenerated(false)
        }}
        autoComplete="off"
        aria-label="Recovery key"
        placeholder="Recovery key"
        className="mono min-h-11 w-full bg-transparent text-sm outline-none"
      />
      <button
        type="button"
        onClick={() => setShow((v) => !v)}
        aria-label={show ? 'Hide recovery key' : 'Show recovery key'}
        className="flex size-11 shrink-0 items-center justify-center"
      >
        {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
      </button>
    </div>
  )

  return (
    <section className="rounded-3xl p-5 glass-card">
      <div className="flex items-center gap-2">
        <LockKeyhole className="size-5" />
        <h2 className="display text-lg font-semibold">{profile ? 'Vault locked' : 'Set up your private vault'}</h2>
      </div>

      {profile ? (
        <div className="mt-3 space-y-3">
          {canBiometric && (
            <button
              onClick={unlockBio}
              disabled={busy}
              className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl text-sm font-semibold disabled:opacity-40"
              style={{ background: 'var(--accent)', color: '#fff' }}
            >
              <Fingerprint className="size-4" /> Unlock with fingerprint or face
            </button>
          )}
          {profile.passkey && !canBiometric && (
            <p className="text-xs text-pretty" style={{ color: 'var(--muted)' }}>
              Fingerprint or face unlock is not available in this browser or window. Use your recovery key.
            </p>
          )}
          <p className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Or use your paper recovery key
          </p>
          {keyField}
          <button
            onClick={unlockRecovery}
            disabled={busy || !longEnough}
            className="min-h-11 w-full rounded-2xl text-sm font-semibold glass-inner disabled:opacity-40"
          >
            Unlock with recovery key
          </button>
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          <p className="text-sm text-pretty" style={{ color: 'var(--muted)' }}>
            Your files are locked with a key that exists only on your paper recovery key, and optionally your fingerprint
            or face. Nothing is uploaded.
          </p>
          <button
            type="button"
            onClick={generate}
            className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl text-sm font-semibold glass-inner"
          >
            <KeyRound className="size-4" /> Generate a strong recovery key
          </button>
          {keyField}
          {generated && (
            <p
              className="rounded-xl p-3 text-xs text-pretty"
              style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--danger)' }}
            >
              This key is shown only now and is never saved. It is the only way back in if your fingerprint, face or
              device is lost. Write it on paper and keep it offline.
            </p>
          )}
          <label className="flex cursor-pointer items-start gap-3 text-sm">
            <input
              type="checkbox"
              checked={written}
              onChange={(e) => setWritten(e.target.checked)}
              className="mt-0.5 size-5 shrink-0"
            />
            <span className="text-pretty">I wrote my recovery key on paper and I know I cannot get it back.</span>
          </label>
          <button
            onClick={create}
            disabled={busy || !longEnough || !written}
            className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl text-sm font-semibold disabled:opacity-40"
            style={{ background: 'var(--accent)', color: '#fff' }}
          >
            {busy && <Loader2 className="size-4 animate-spin" />} Create my vault
          </button>

          <div className="border-t pt-3" style={{ borderColor: 'var(--border)' }}>
            <p className="text-xs text-pretty" style={{ color: 'var(--muted)' }}>
              Already have a vault on another device? Enter its recovery key above, then choose any encrypted .ipvault copy.
            </p>
            <label
              className="mt-2 flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-2xl text-sm font-semibold glass-inner"
              style={{ opacity: busy || !longEnough ? 0.4 : 1, pointerEvents: busy || !longEnough ? 'none' : 'auto' }}
            >
              <Upload className="size-4" /> Restore from an encrypted copy
              <input
                type="file"
                className="sr-only"
                disabled={busy || !longEnough}
                onChange={(e) => {
                  restore(e.target.files?.[0])
                  e.target.value = ''
                }}
              />
            </label>
          </div>
        </div>
      )}
    </section>
  )
}
