import { useState } from 'react'
import { toast } from 'sonner'
import { Landmark, Loader2 } from 'lucide-react'
import { clearGovKey, hasGovKey, loadGovKey, saveGovKey } from '@/lib/govKeyStore'
import { GovApiError, parseParams, parseTarget, prettyBody, runGovRequest, type GovResult } from '@/lib/govApi'
import { VaultError } from '@/lib/vaultCrypto'

interface GovApiToolProps {
  sessionKey: CryptoKey
  /** Encrypts the file into the vault. */
  onSave: (file: File, label: string) => Promise<void>
}

const PREVIEW_CHARS = 20_000

export function GovApiTool({ sessionKey, onSave }: GovApiToolProps) {
  const [saved, setSaved] = useState(hasGovKey)
  const [keyInput, setKeyInput] = useState('')
  const [address, setAddress] = useState('')
  const [params, setParams] = useState('')
  const [keyInAddress, setKeyInAddress] = useState(false)
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState<GovResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  let host = ''
  try {
    host = address.trim() ? new URL(address.trim()).hostname : ''
  } catch {
    host = ''
  }

  const storeKey = async () => {
    const trimmed = keyInput.trim()
    if (trimmed.length < 8) return
    await saveGovKey(sessionKey, trimmed)
    setKeyInput('')
    setSaved(true)
    toast.success('Key saved. It is encrypted with your vault key.')
  }

  const removeKey = () => {
    if (!window.confirm('Remove the saved key from this device?')) return
    clearGovKey()
    setSaved(false)
  }

  const run = async () => {
    setError(null)
    setResult(null)
    setBusy(true)
    try {
      const target = parseTarget(address)
      const parsed = parseParams(params)
      const apiKey = await loadGovKey(sessionKey)
      if (!apiKey) throw new GovApiError('Save your key first.')
      setResult(await runGovRequest({ target, params: parsed, apiKey, keyInHeader: !keyInAddress }))
    } catch (err) {
      setError(err instanceof GovApiError || err instanceof VaultError ? err.message : 'That did not work. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  const saveEvidence = async () => {
    if (!result) return
    const record = {
      retrievedAt: new Date().toISOString(),
      address: result.address,
      status: result.status,
      contentType: result.contentType,
      truncated: result.truncated,
      body: prettyBody(result),
    }
    const file = new File([JSON.stringify(record, null, 2)], 'government-record.json', { type: 'application/json' })
    try {
      await onSave(file, `Government record ${new Date().toLocaleDateString()}`)
      toast.success('Saved to your vault, encrypted. Register its fingerprint for a dated record.')
    } catch {
      toast.error('Could not save to the vault.')
    }
  }

  const shown = result ? prettyBody(result) : ''

  return (
    <section className="rounded-3xl p-5 glass-card">
      <div className="flex items-center gap-2">
        <Landmark className="size-5" />
        <h3 className="display text-lg font-semibold">Government records</h3>
      </div>
      <p className="mt-1.5 text-sm text-pretty" style={{ color: 'var(--muted)' }}>
        Look up public records from a federal agency using your api.data.gov key, and save what you find as encrypted
        evidence. Your key is stored encrypted on this device and is never shown in the app or sent anywhere except the
        .gov address you choose.
      </p>

      <div className="mt-4 rounded-2xl p-4 glass-inner">
        <div className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
          {saved ? 'Your key is saved (encrypted)' : 'Your api.data.gov key'}
        </div>
        {saved ? (
          <button onClick={removeKey} className="mt-1 min-h-11 text-xs font-semibold underline">
            Remove saved key
          </button>
        ) : (
          <div className="mt-2 space-y-2">
            <input
              type="password"
              value={keyInput}
              onChange={(e) => setKeyInput(e.target.value)}
              autoComplete="off"
              placeholder="Type or paste it here, not in a chat"
              aria-label="api.data.gov key"
              className="field mono min-h-11 w-full rounded-xl bg-white/70 px-3 text-sm outline-none"
              style={{ border: '1px solid var(--border)' }}
            />
            <button
              onClick={() => void storeKey()}
              disabled={keyInput.trim().length < 8}
              className="min-h-11 w-full rounded-xl text-sm font-semibold disabled:opacity-40"
              style={{ background: 'var(--accent)', color: '#fff' }}
            >
              Save key to my vault
            </button>
          </div>
        )}
      </div>

      <div className="mt-3 space-y-3">
        <label className="block text-xs font-semibold" style={{ color: 'var(--muted)' }}>
          Agency API address
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="https://api.agency.gov/..."
            className="field mono mt-1 min-h-11 w-full rounded-xl bg-white/70 px-3 text-sm font-normal outline-none"
            style={{ border: '1px solid var(--border)' }}
          />
        </label>
        <label className="block text-xs font-semibold" style={{ color: 'var(--muted)' }}>
          Options, one per line as name=value (optional)
          <textarea
            value={params}
            onChange={(e) => setParams(e.target.value)}
            rows={3}
            placeholder={'q=copyright\nlimit=10'}
            className="field mono mt-1 w-full rounded-xl bg-white/70 px-3 py-2 text-sm font-normal outline-none"
            style={{ border: '1px solid var(--border)' }}
          />
        </label>
        <label className="flex cursor-pointer items-start gap-3 text-xs">
          <input
            type="checkbox"
            checked={keyInAddress}
            onChange={(e) => setKeyInAddress(e.target.checked)}
            className="mt-0.5 size-5 shrink-0"
          />
          <span className="text-pretty" style={{ color: 'var(--muted)' }}>
            Send the key in the address instead of a header. Only use this if the agency refuses the header. In the Arc
            Studio builder preview, the request log records the address, so the key would show up there.
          </span>
        </label>
        {host && (
          <p className="text-xs text-pretty" style={{ color: host.endsWith('.gov') ? 'var(--muted)' : 'var(--danger)' }}>
            {host.endsWith('.gov') ? `Your key will be sent to ${host}.` : `${host} is not a .gov address. Your key will not be sent.`}
          </p>
        )}
        <button
          onClick={() => void run()}
          disabled={busy || !saved || address.trim() === ''}
          className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl text-sm font-semibold disabled:opacity-40"
          style={{ background: 'var(--accent)', color: '#fff' }}
        >
          {busy && <Loader2 className="size-4 animate-spin" />} Look it up
        </button>
      </div>

      {error && (
        <p className="mt-3 rounded-xl p-3 text-xs text-pretty" style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--danger)' }}>
          {error}
        </p>
      )}

      {result && (
        <div className="mt-4 space-y-2">
          <div className="text-xs font-semibold" style={{ color: result.ok ? 'var(--success)' : 'var(--danger)' }}>
            {result.ok ? 'Received' : 'The agency answered with an error'} (status {result.status})
          </div>
          <pre
            className="mono max-h-72 overflow-auto whitespace-pre-wrap break-words rounded-2xl p-3 text-[11px] glass-inner"
            style={{ color: 'var(--ink-2)' }}
          >
            {shown.slice(0, PREVIEW_CHARS)}
            {shown.length > PREVIEW_CHARS ? '\n... (shortened here, the full record is saved)' : ''}
          </pre>
          <button
            onClick={() => void saveEvidence()}
            className="min-h-11 w-full rounded-xl text-sm font-semibold glass-inner"
          >
            Save as encrypted evidence
          </button>
          <p className="text-[11px] text-pretty" style={{ color: 'var(--subtle)' }}>
            The saved record includes the address and time, never your key.
          </p>
        </div>
      )}
    </section>
  )
}
