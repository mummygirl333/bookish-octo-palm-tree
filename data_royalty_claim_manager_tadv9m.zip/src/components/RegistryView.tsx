import { Database } from 'lucide-react'
import { zeroHash } from 'viem'
import { kindLabel, type AssetView } from '@/contracts/registry'
import { fmtUsdc, relativeDate, shortAddress } from '@/lib/format'

interface RegistryViewProps {
  assets: AssetView[]
  isLoading: boolean
  onPay: (asset: AssetView) => void
}

export function RegistryView({ assets, isLoading, onPay }: RegistryViewProps) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="h-28 animate-pulse rounded-3xl glass-card" />
        ))}
      </div>
    )
  }

  if (assets.length === 0) {
    return (
      <div className="rounded-3xl p-8 text-center glass-card">
        <Database className="mx-auto size-8" style={{ color: 'var(--subtle)' }} />
        <p className="display mt-3 text-lg font-semibold">No IP registered yet</p>
        <p className="mx-auto mt-1 max-w-xs text-sm text-pretty" style={{ color: 'var(--muted)' }}>
          Register the first work from the My IP tab. Sites can then pay you for every use.
        </p>
      </div>
    )
  }

  return (
    <ul className="space-y-3">
      {assets.map((d) => (
        <li key={d.id.toString()} className="rounded-3xl p-5 glass-card">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>
                {kindLabel(d.kind)} · #{d.id.toString()} · {relativeDate(d.registeredAt)}
              </div>
              <h3 className="mt-0.5 break-words text-base font-semibold text-balance">{d.uri}</h3>
              <div className="mono mt-1 text-[11px]" style={{ color: 'var(--subtle)' }}>
                Owner {shortAddress(d.owner)}
              </div>
              {d.createdAt > 0n && (
                <div className="mt-1 text-[11px]" style={{ color: 'var(--muted)' }}>
                  Originally created {relativeDate(d.createdAt)} (stated by owner)
                </div>
              )}
              {d.noticeCount > 0n && (
                <div className="mt-1 text-[11px] font-semibold" style={{ color: 'var(--danger)' }}>
                  {d.noticeCount.toString()} unauthorized-use notice{d.noticeCount === 1n ? '' : 's'} recorded by owner
                  (unverified statement)
                </div>
              )}
              {d.licenseUri && (
                <div className="mt-1 break-all text-[11px]" style={{ color: 'var(--muted)' }}>
                  License: {d.licenseUri}
                </div>
              )}
            </div>
            <div className="flex shrink-0 flex-col items-end gap-1">
            <span
              className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold"
              style={{
                background: d.active ? 'rgba(26,128,71,0.1)' : 'rgba(107,101,128,0.12)',
                color: d.active ? 'var(--success)' : 'var(--muted)',
              }}
            >
              {d.active ? 'Open' : 'Paused'}
            </span>
            {d.copyrightRef !== zeroHash && (
              <span
                className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold"
                style={{ background: 'rgba(26,128,71,0.1)', color: 'var(--success)' }}
              >
                Copyright record on file
              </span>
            )}
            {!d.transferable && (
              <span
                className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold"
                style={{ background: 'rgba(16,97,166,0.1)', color: 'var(--accent-hover)' }}
              >
                Locked to creator
              </span>
            )}
            </div>
          </div>

          <dl className="mt-4 grid grid-cols-3 gap-2 text-center">
            <Stat label="Per use" value={`${fmtUsdc(d.pricePerUse)}`} />
            <Stat label="Uses paid" value={d.totalUses.toLocaleString()} />
            <Stat label="Earned" value={fmtUsdc(d.totalEarned)} />
          </dl>

          <button
            onClick={() => onPay(d)}
            disabled={!d.active || d.pricePerUse === 0n}
            className="mt-4 min-h-11 w-full rounded-2xl px-4 py-2.5 text-sm font-semibold transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
            style={{ background: 'var(--accent)', color: '#fff' }}
          >
            Pay royalties for use
          </button>
        </li>
      ))}
    </ul>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl px-2 py-2.5 glass-inner">
      <dd className="display text-sm font-bold tabular-nums">{value}</dd>
      <dt className="text-[10px] uppercase" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
        {label}
      </dt>
    </div>
  )
}
