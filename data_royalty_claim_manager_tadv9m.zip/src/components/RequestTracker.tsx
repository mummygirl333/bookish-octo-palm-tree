import { useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { ClipboardList, Copy, Trash2 } from 'lucide-react'
import { buildLetter } from '@/lib/requestLetter'
import {
  daysLeft,
  isOverdue,
  loadRequests,
  saveRequests,
  type DataRequest,
  type RequestKind,
  type RequestMethod,
  type RequestStatus,
} from '@/lib/requestStore'

const KINDS: Array<{ id: RequestKind; label: string }> = [
  { id: 'both', label: 'Copy and delete' },
  { id: 'access', label: 'Copy of my data' },
  { id: 'delete', label: 'Delete my data' },
]

const METHODS: Array<{ id: RequestMethod; label: string }> = [
  { id: 'portal', label: 'Privacy portal' },
  { id: 'email', label: 'Email' },
  { id: 'mail', label: 'Mail' },
]

const STATUSES: Array<{ id: RequestStatus; label: string }> = [
  { id: 'waiting', label: 'Waiting for reply' },
  { id: 'replied', label: 'Replied' },
  { id: 'refused', label: 'Refused' },
]

const today = () => new Date().toISOString().slice(0, 10)

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text)
    toast.success('Letter copied. Fill in the [brackets] before you send it.')
  } catch {
    toast.error('Could not copy. Select the text in the preview and copy it by hand.')
  }
}

export function RequestTracker({ sessionKey }: { sessionKey: CryptoKey }) {
  const [requests, setRequests] = useState<DataRequest[]>([])
  const [loaded, setLoaded] = useState(false)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [company, setCompany] = useState('')
  const [kind, setKind] = useState<RequestKind>('both')
  const [method, setMethod] = useState<RequestMethod>('portal')
  const [sentOn, setSentOn] = useState(today)
  const [dueInDays, setDueInDays] = useState('45')
  const queue = useRef<Promise<void>>(Promise.resolve())

  useEffect(() => {
    let active = true
    loadRequests(sessionKey)
      .then((found) => {
        if (!active) return
        setRequests(found)
        setLoaded(true)
      })
      .catch((err: unknown) => {
        if (active) setLoadError(err instanceof Error ? err.message : 'Could not open your saved requests.')
      })
    return () => {
      active = false
    }
  }, [sessionKey])

  const commit = (next: DataRequest[]) => {
    setRequests(next)
    // Saves run one after another, so the newest list is always the one written last.
    queue.current = queue.current
      .then(() => saveRequests(sessionKey, next))
      .catch(() => {
        toast.error('Could not save to this browser.')
      })
  }

  const dueN = /^\d{1,3}$/.test(dueInDays) ? Number(dueInDays) : 0
  const canAdd = loaded && company.trim().length > 0 && dueN > 0 && sentOn !== ''

  const add = () => {
    if (!canAdd) return
    commit([
      {
        id: crypto.randomUUID(),
        company: company.trim(),
        kind,
        method,
        sentOn,
        dueInDays: dueN,
        status: 'waiting',
        notes: '',
      },
      ...requests,
    ])
    setCompany('')
  }

  const update = (id: string, patch: Partial<DataRequest>) =>
    commit(requests.map((r) => (r.id === id ? { ...r, ...patch } : r)))

  const remove = (r: DataRequest) => {
    if (!window.confirm(`Remove your request to ${r.company} from this list?`)) return
    commit(requests.filter((x) => x.id !== r.id))
  }

  const overdue = requests.filter((r) => isOverdue(r))

  return (
    <section className="rounded-3xl p-5 glass-card">
      <div className="flex items-center gap-2">
        <ClipboardList className="size-5" />
        <h3 className="display text-lg font-semibold">Data requests</h3>
      </div>
      <p className="mt-1.5 text-sm text-pretty" style={{ color: 'var(--muted)' }}>
        Keep track of requests asking a company what data it holds about you, for a copy, or to delete it. Everything here
        is encrypted with your vault key and stays on this device.
      </p>

      {overdue.length > 0 && (
        <p
          className="mt-3 rounded-xl p-3 text-xs font-semibold text-pretty"
          style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--danger)' }}
        >
          {overdue.length === 1 ? '1 request is' : `${overdue.length} requests are`} past the reply date:{' '}
          {overdue.map((r) => r.company).join(', ')}. Send a follow-up in writing and keep a copy.
        </p>
      )}
      {loadError && (
        <p className="mt-3 text-xs" style={{ color: 'var(--danger)' }}>
          {loadError}
        </p>
      )}

      <div className="mt-4 space-y-3 rounded-2xl p-4 glass-inner">
        <input
          value={company}
          onChange={(e) => setCompany(e.target.value.slice(0, 80))}
          placeholder="Company you are writing to"
          aria-label="Company"
          className="field min-h-11 w-full rounded-xl bg-white/70 px-3 text-sm outline-none"
          style={{ border: '1px solid var(--border)' }}
        />
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="What you are asking for">
          {KINDS.map((k) => (
            <Chip key={k.id} active={kind === k.id} onClick={() => setKind(k.id)} label={k.label} />
          ))}
        </div>
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="How you sent it">
          {METHODS.map((m) => (
            <Chip key={m.id} active={method === m.id} onClick={() => setMethod(m.id)} label={m.label} />
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <label className="block text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Sent on
            <input
              type="date"
              value={sentOn}
              max={today()}
              onChange={(e) => setSentOn(e.target.value)}
              className="field mt-1 min-h-11 w-full rounded-xl bg-white/70 px-3 text-sm font-normal outline-none"
              style={{ border: '1px solid var(--border)' }}
            />
          </label>
          <label className="block text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Reply due in (days)
            <input
              inputMode="numeric"
              value={dueInDays}
              onChange={(e) => setDueInDays(e.target.value.replace(/\D/g, '').slice(0, 3))}
              className="field mt-1 min-h-11 w-full rounded-xl bg-white/70 px-3 text-sm font-normal tabular-nums outline-none"
              style={{ border: '1px solid var(--border)' }}
            />
          </label>
        </div>
        <p className="text-[11px] text-pretty" style={{ color: 'var(--subtle)' }}>
          The reply deadline differs by law and company. 45 days is a common one. Check what applies to you.
        </p>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => void copyText(buildLetter(company, kind))}
            className="flex min-h-11 items-center justify-center gap-2 rounded-xl text-sm font-semibold"
            style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
          >
            <Copy className="size-4" /> Copy letter
          </button>
          <button
            onClick={add}
            disabled={!canAdd}
            className="min-h-11 rounded-xl text-sm font-semibold disabled:opacity-40"
            style={{ background: 'var(--accent)', color: '#fff' }}
          >
            Add to my list
          </button>
        </div>
        <details className="text-xs">
          <summary className="min-h-11 cursor-pointer py-2.5 font-semibold">Preview the letter</summary>
          <pre className="mono whitespace-pre-wrap break-words text-[11px]" style={{ color: 'var(--ink-2)' }}>
            {buildLetter(company, kind)}
          </pre>
          <p className="mt-2 text-[11px] text-pretty" style={{ color: 'var(--subtle)' }}>
            This is a template, not legal advice. Fill in your own details outside this app. Never put them here.
          </p>
        </details>
      </div>

      {requests.length === 0 && loaded && (
        <p className="mt-4 text-center text-sm" style={{ color: 'var(--muted)' }}>
          No requests yet.
        </p>
      )}

      <ul className="mt-4 space-y-3">
        {requests.map((r) => {
          const left = daysLeft(r)
          const late = isOverdue(r)
          return (
            <li key={r.id} className="rounded-2xl p-4 glass-inner">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="break-words text-sm font-semibold">{r.company}</div>
                  <div className="text-xs" style={{ color: 'var(--muted)' }}>
                    {KINDS.find((k) => k.id === r.kind)?.label} · {METHODS.find((m) => m.id === r.method)?.label} · sent{' '}
                    {r.sentOn}
                  </div>
                  {r.status === 'waiting' && (
                    <div
                      className="mt-1 text-xs font-semibold tabular-nums"
                      style={{ color: late ? 'var(--danger)' : 'var(--ink-2)' }}
                    >
                      {late
                        ? `${Math.abs(left)} day${Math.abs(left) === 1 ? '' : 's'} overdue`
                        : `Reply due in ${left} day${left === 1 ? '' : 's'}`}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => remove(r)}
                  aria-label={`Remove request to ${r.company}`}
                  className="flex size-11 shrink-0 items-center justify-center rounded-xl"
                  style={{ color: 'var(--danger)' }}
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
              <select
                value={r.status}
                onChange={(e) => update(r.id, { status: e.target.value as RequestStatus })}
                aria-label={`Status of request to ${r.company}`}
                className="mt-2 min-h-11 w-full rounded-xl bg-white/70 px-3 text-sm"
                style={{ border: '1px solid var(--border)' }}
              >
                {STATUSES.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.label}
                  </option>
                ))}
              </select>
              <textarea
                value={r.notes}
                onChange={(e) => update(r.id, { notes: e.target.value.slice(0, 500) })}
                placeholder="Notes: what they said, reference numbers (keep names and IDs out)"
                aria-label={`Notes for request to ${r.company}`}
                rows={2}
                className="field mt-2 w-full rounded-xl bg-white/70 px-3 py-2 text-sm outline-none"
                style={{ border: '1px solid var(--border)' }}
              />
              {r.status !== 'waiting' && (
                <p className="mt-2 text-[11px] text-pretty" style={{ color: 'var(--subtle)' }}>
                  Keep their reply: encrypt it in the vault above, then register its fingerprint if you want a dated record.
                </p>
              )}
            </li>
          )
        })}
      </ul>
    </section>
  )
}

function Chip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={active}
      onClick={onClick}
      className="min-h-11 rounded-full px-4 text-xs font-semibold transition-colors"
      style={
        active
          ? { background: 'var(--accent)', color: '#fff' }
          : { background: 'var(--surface-strong)', border: '1px solid var(--border)' }
      }
    >
      {label}
    </button>
  )
}
