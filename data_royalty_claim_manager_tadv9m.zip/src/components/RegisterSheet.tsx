import { useEffect, useState } from 'react'
import { bytesToHex, encodeAbiParameters, keccak256, zeroHash, type Hex } from 'viem'
import { useAccount, useWriteContract } from 'wagmi'
import { FileUp } from 'lucide-react'
import { ASSET_KINDS, CHAIN_ID, REGISTRY_ADDRESS, kindLabel, registryAbi } from '@/contracts/registry'
import { useSend } from '@/hooks/useSend'
import type { PendingRegistration } from '@/hooks/usePending'
import { parseUsdc } from '@/onchain-money'
import { fmtUsdc } from '@/lib/format'
import { HASH_RE, sha256Hex } from '@/lib/fingerprint'
import { Sheet } from './Sheet'
import { TxButton, TxReceipt } from './TxButton'

interface RegisterSheetProps {
  open: boolean
  onClose: () => void
  resume: PendingRegistration | null
  prefill?: { contentHash: Hex; label: string } | null
  onCommitted: (entry: PendingRegistration) => void
  onFinished: (commitment: Hex) => void
}

function randomSalt(): Hex {
  return bytesToHex(crypto.getRandomValues(new Uint8Array(32)))
}

function commitmentOf(owner: `0x${string}`, contentHash: Hex, salt: Hex): Hex {
  return keccak256(
    encodeAbiParameters([{ type: 'address' }, { type: 'bytes32' }, { type: 'bytes32' }], [owner, contentHash, salt]),
  )
}

export function RegisterSheet({ open, onClose, resume, prefill, onCommitted, onFinished }: RegisterSheetProps) {
  const { address } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const { send, status, hash, error, reset } = useSend()
  const [kind, setKind] = useState(0)
  const [uri, setUri] = useState('')
  const [licenseUri, setLicenseUri] = useState('')
  const [createdOn, setCreatedOn] = useState('')
  const [locked, setLocked] = useState(true)
  const [copyrightRef, setCopyrightRef] = useState('')
  const [copyrightFile, setCopyrightFile] = useState('')
  const [contentHash, setContentHash] = useState('')
  const [fileName, setFileName] = useState('')
  const [price, setPrice] = useState('0.001')
  const [hashing, setHashing] = useState(false)
  const [stage, setStage] = useState<PendingRegistration | null>(null)

  useEffect(() => {
    if (open) {
      reset()
      setStage(resume)
      if (!resume) {
        setKind(0)
        setUri('')
        setLicenseUri('')
        setCreatedOn('')
        setLocked(true)
        setCopyrightRef('')
        setCopyrightFile('')
        setContentHash('')
        setFileName('')
        setPrice('0.001')
        if (prefill) {
          setContentHash(prefill.contentHash)
          setUri(prefill.label)
          setFileName('From your private vault')
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, resume])

  let priceRaw: bigint | null = null
  try {
    priceRaw = price.trim() ? parseUsdc(price) : null
  } catch {
    priceRaw = null
  }
  const uriBytes = new TextEncoder().encode(uri).length
  const licenseBytes = new TextEncoder().encode(licenseUri).length
  const createdAtSeconds = createdOn ? Math.floor(Date.parse(`${createdOn}T00:00:00Z`) / 1000) : 0
  const createdValid = !createdOn || (Number.isFinite(createdAtSeconds) && createdAtSeconds <= Math.floor(Date.now() / 1000))
  const copyrightValid = !copyrightRef || HASH_RE.test(copyrightRef)
  const formValid =
    createdValid &&
    copyrightValid &&
    HASH_RE.test(contentHash) && uri.trim().length > 0 && uriBytes <= 256 && licenseBytes <= 256 && priceRaw !== null && priceRaw > 0n

  const onFile = async (file: File | undefined) => {
    if (!file) return
    setHashing(true)
    try {
      setContentHash(await sha256Hex(file))
      setFileName(file.name)
      if (!uri) setUri(file.name)
    } finally {
      setHashing(false)
    }
  }

  const reserve = async () => {
    const registry = REGISTRY_ADDRESS
    if (!address || !registry || priceRaw === null) return
    const salt = randomSalt()
    const hashHex = contentHash as Hex
    const commitment = commitmentOf(address, hashHex, salt)
    const entry: PendingRegistration = {
      owner: address,
      commitment,
      contentHash: hashHex,
      kind,
      uri: uri.trim(),
      licenseUri: licenseUri.trim(),
      createdAt: String(createdAtSeconds),
      transferable: !locked,
      copyrightRef: copyrightRef ? (copyrightRef as Hex) : zeroHash,
      priceRaw: priceRaw.toString(),
      salt,
    }
    const ok = await send(
      () =>
        writeContractAsync({
          address: registry,
          abi: registryAbi,
          functionName: 'commitRegistration',
          args: [commitment],
          chainId: CHAIN_ID,
        }),
      'Claim reserved. One more step to finish.',
    )
    if (ok) {
      onCommitted(entry)
      setStage(entry)
    }
  }

  const finish = async () => {
    const registry = REGISTRY_ADDRESS
    if (!registry || !stage) return
    const ok = await send(
      () =>
        writeContractAsync({
          address: registry,
          abi: registryAbi,
          functionName: 'registerAsset',
          args: [
            {
              kind: stage.kind,
              uri: stage.uri,
              licenseUri: stage.licenseUri,
              contentHash: stage.contentHash,
              pricePerUse: BigInt(stage.priceRaw),
              createdAt: BigInt(stage.createdAt),
              transferable: stage.transferable,
              copyrightRef: stage.copyrightRef,
            },
            stage.salt,
          ],
          chainId: CHAIN_ID,
        }),
      'IP registered. You can now earn royalties.',
    )
    if (ok) {
      onFinished(stage.commitment)
      setStage(null)
      onClose()
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title={stage ? 'Finish your registration' : 'Register your IP'}>
      {stage ? (
        <div className="space-y-4">
          <p className="text-sm text-pretty" style={{ color: 'var(--muted)' }}>
            Step 1 is done: your claim is reserved so no one can copy it. Step 2 publishes it and makes you the owner.
          </p>
          <div className="space-y-1 rounded-2xl p-4 text-sm glass-inner">
            <div className="break-all font-semibold">{stage.uri}</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>
              {kindLabel(stage.kind)}
              {stage.licenseUri ? ` · License: ${stage.licenseUri}` : ''}
              {!stage.transferable ? ' · Locked to your wallet' : ''}
              {stage.copyrightRef !== zeroHash ? ' · Copyright record referenced' : ''}
            </div>
            <div className="mono break-all text-[11px]" style={{ color: 'var(--subtle)' }}>
              {stage.contentHash}
            </div>
            <div className="pt-1 text-xs tabular-nums" style={{ color: 'var(--muted)' }}>
              {fmtUsdc(BigInt(stage.priceRaw))} USDC per use
            </div>
          </div>
          <TxButton label="Step 2: Finish registration" onClick={finish} status={status} />
          <TxReceipt status={status} hash={hash} error={error} />
        </div>
      ) : (
        <div className="space-y-4">
          <p className="text-sm text-pretty" style={{ color: 'var(--muted)' }}>
            Register a work you created or own: art, writing, software, designs, data and more. The file is fingerprinted in your browser and never uploaded.
          </p>

          <div
            className="rounded-2xl p-4 text-xs text-pretty glass-inner"
            style={{ color: 'var(--ink-2)' }}
          >
            <p className="font-semibold">Your work stays private.</p>
            <p className="mt-1">
              Only a fingerprint, the title, and the license link are published, and they are permanent. Use a neutral
              title and keep personal details out of these fields. Register before you share the work with anyone, since
              the first fingerprint registered wins.
            </p>
          </div>

          <label
            className="flex min-h-11 cursor-pointer items-center gap-3 rounded-2xl border border-dashed p-4 text-sm glass-inner"
            style={{ borderColor: 'var(--border-strong)' }}
          >
            <FileUp className="size-5 shrink-0" />
            <span className="min-w-0 truncate">
              {hashing ? 'Fingerprinting...' : fileName || 'Choose a file to fingerprint'}
            </span>
            <input type="file" className="sr-only" onChange={(e) => void onFile(e.target.files?.[0])} />
          </label>

          <div>
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              What kind of IP is it?
            </span>
            <div className="mt-1 flex flex-wrap gap-2" role="radiogroup" aria-label="IP type">
              {ASSET_KINDS.map((k) => (
                <button
                  key={k.id}
                  type="button"
                  role="radio"
                  aria-checked={kind === k.id}
                  onClick={() => setKind(k.id)}
                  className="min-h-11 rounded-full px-4 text-xs font-semibold transition-colors"
                  style={
                    kind === k.id
                      ? { background: 'var(--accent)', color: '#fff' }
                      : { background: 'var(--surface-muted)', border: '1px solid var(--border)' }
                  }
                >
                  {k.label}
                </button>
              ))}
            </div>
          </div>

          <label className="block">
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              Or paste a SHA-256 fingerprint
            </span>
            <input
              value={contentHash}
              onChange={(e) => {
                setContentHash(e.target.value.trim())
                setFileName('')
              }}
              placeholder="0x..."
              className="field mono mt-1 w-full rounded-2xl px-3 py-3 text-xs outline-none glass-inner"
            />
          </label>

          <label className="block">
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              Title or link to the work
            </span>
            <input
              value={uri}
              onChange={(e) => setUri(e.target.value)}
              placeholder="ipfs://... or Product reviews 2024"
              className="field mt-1 w-full rounded-2xl px-3 py-3 text-sm outline-none glass-inner"
            />
          </label>

          <label className="block">
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              When did you originally create it? (optional)
            </span>
            <input
              type="date"
              value={createdOn}
              max={new Date().toISOString().slice(0, 10)}
              onChange={(e) => setCreatedOn(e.target.value)}
              className="field mt-1 min-h-11 w-full rounded-2xl px-3 text-sm outline-none glass-inner"
            />
            <span className="mt-1 block text-[11px]" style={{ color: 'var(--subtle)' }}>
              Works can predate this registry. This date is your own statement, not proof.
            </span>
          </label>

          <div className="rounded-2xl p-4 glass-inner">
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              Already hold a copyright registration? (optional)
            </span>
            <p className="mt-1 text-[11px] text-pretty" style={{ color: 'var(--subtle)' }}>
              Choose your registration certificate. Only its fingerprint is published, so it can be matched later without
              exposing it. Never enter your legal name, biometric or identity data in any field here.
            </p>
            <label className="mt-2 flex min-h-11 cursor-pointer items-center gap-3 rounded-xl bg-white/60 px-3 text-sm">
              <FileUp className="size-4 shrink-0" />
              <span className="min-w-0 truncate">{copyrightFile || 'Choose certificate to fingerprint'}</span>
              <input
                type="file"
                className="sr-only"
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (!f) return
                  void sha256Hex(f).then((h) => {
                    setCopyrightRef(h)
                    setCopyrightFile(f.name)
                  })
                }}
              />
            </label>
            {copyrightRef && (
              <p className="mono mt-2 break-all text-[10px]" style={{ color: 'var(--subtle)' }}>
                {copyrightRef}
              </p>
            )}
          </div>

          <label className="block">
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              License terms link (optional)
            </span>
            <input
              value={licenseUri}
              onChange={(e) => setLicenseUri(e.target.value)}
              placeholder="https://... or ipfs://..."
              className="field mt-1 w-full rounded-2xl px-3 py-3 text-sm outline-none glass-inner"
            />
          </label>

          <label className="block">
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              Royalty per use (USDC)
            </span>
            <div className="field mt-1 flex items-baseline gap-2 rounded-2xl p-3 glass-inner">
              <input
                inputMode="decimal"
                value={price}
                onChange={(e) => {
                  const v = e.target.value.replace(/[^0-9.]/g, '')
                  if (/^\d*\.?\d{0,6}$/.test(v)) setPrice(v)
                }}
                className="display w-full bg-transparent text-3xl font-bold tabular-nums outline-none"
                aria-label="Royalty per use in USDC"
              />
              <span className="text-sm" style={{ color: 'var(--subtle)' }}>
                USDC
              </span>
            </div>
          </label>

          {createdOn && !createdValid && (
            <p className="text-xs" style={{ color: 'var(--danger)' }}>
              The creation date cannot be in the future.
            </p>
          )}

          {contentHash && !HASH_RE.test(contentHash) && (
            <p className="text-xs" style={{ color: 'var(--danger)' }}>
              The fingerprint must be 0x followed by 64 hex characters.
            </p>
          )}

          <label className="flex cursor-pointer items-start gap-3 rounded-2xl p-4 glass-inner">
            <input
              type="checkbox"
              checked={locked}
              onChange={(e) => setLocked(e.target.checked)}
              className="mt-0.5 size-5 shrink-0"
            />
            <span className="text-sm text-pretty">
              <span className="font-semibold">Lock to my wallet.</span>{' '}
              <span style={{ color: 'var(--muted)' }}>
                Ownership can never be transferred, and only this wallet can set the price, pause payments, or claim
                royalties. This cannot be undone.
              </span>
            </span>
          </label>

          <TxButton label="Step 1: Reserve my claim" onClick={reserve} status={status} disabled={!formValid} />
          <TxReceipt status={status} hash={hash} error={error} />
        </div>
      )}
    </Sheet>
  )
}
