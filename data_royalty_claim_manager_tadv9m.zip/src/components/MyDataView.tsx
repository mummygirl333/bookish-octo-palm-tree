import { useState } from 'react'
import { useAccount, useWriteContract } from 'wagmi'
import { Plus, Wallet } from 'lucide-react'
import { CHAIN_ID, REGISTRY_ADDRESS, kindLabel, registryAbi, type AssetView } from '@/contracts/registry'
import type { PendingRegistration } from '@/hooks/usePending'
import { useSend } from '@/hooks/useSend'
import { fmtUsdc, shortAddress } from '@/lib/format'
import { HASH_RE, sha256Hex } from '@/lib/fingerprint'
import { parseUsdc } from '@/onchain-money'
import { TxButton, TxReceipt } from './TxButton'

interface MyDataViewProps {
  assets: AssetView[]
  pending: PendingRegistration[]
  onRegister: () => void
  onResume: (entry: PendingRegistration) => void
}

const MAX_BATCH = 50

export function MyDataView({ assets, pending, onRegister, onResume }: MyDataViewProps) {
  const { address, isConnected } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const { send, status, hash, error } = useSend()

  const mine = address ? assets.filter((d) => d.owner.toLowerCase() === address.toLowerCase()) : []
  const claimable = mine.filter((d) => d.unclaimed > 0n)
  const totalClaimable = claimable.reduce((sum, d) => sum + d.unclaimed, 0n)
  const lifetime = mine.reduce((sum, d) => sum + d.totalEarned, 0n)

  const claimAll = () => {
    const registry = REGISTRY_ADDRESS
    if (!registry || claimable.length === 0) return
    const ids = claimable.slice(0, MAX_BATCH).map((d) => d.id)
    void send(
      () =>
        writeContractAsync({
          address: registry,
          abi: registryAbi,
          functionName: 'claimMany',
          args: [ids],
          chainId: CHAIN_ID,
        }),
      'Royalties sent to your wallet',
    )
  }

  return (
    <div className="space-y-4">
      <section className="rounded-3xl p-5 glass-card">
        <div className="mb-3 flex items-center gap-1.5">
          <div className="flex size-5 items-center justify-center rounded-md" style={{ background: 'rgba(26,128,71,0.12)' }}>
            <Wallet className="size-3" style={{ color: 'var(--success)' }} />
          </div>
          <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Royalties ready to claim
          </span>
        </div>
        <div className="flex items-baseline gap-1.5">
          <span className="display text-5xl font-bold tabular-nums">{isConnected ? fmtUsdc(totalClaimable) : '0.00'}</span>
          <span className="text-lg font-medium" style={{ color: 'var(--subtle)' }}>
            USDC
          </span>
        </div>
        <p className="mt-1.5 text-xs" style={{ color: 'var(--muted)' }}>
          {isConnected
            ? `${fmtUsdc(lifetime)} USDC earned all time across ${mine.length} work${mine.length === 1 ? '' : 's'}`
            : 'Connect your wallet to see what you are owed'}
        </p>
        <div className="mt-4">
          <TxButton
            label={`Claim ${fmtUsdc(totalClaimable)} USDC`}
            onClick={claimAll}
            status={status}
            disabled={claimable.length === 0}
          />
          <TxReceipt status={status} hash={hash} error={error} />
        </div>
      </section>

      {pending.map((p) => (
        <section key={p.commitment} className="flex items-center justify-between gap-3 rounded-3xl p-4 glass-card">
          <div className="min-w-0">
            <div className="text-xs font-semibold" style={{ color: 'var(--accent-hover)' }}>
              Registration waiting for step 2
            </div>
            <div className="truncate text-sm font-semibold">{p.uri}</div>
          </div>
          <button
            onClick={() => onResume(p)}
            className="min-h-11 shrink-0 rounded-2xl px-4 text-sm font-semibold"
            style={{ background: 'var(--accent)', color: '#fff' }}
          >
            Finish
          </button>
        </section>
      ))}

      <button
        onClick={onRegister}
        className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold glass-card"
      >
        <Plus className="size-4" /> Register new IP
      </button>

      {isConnected && mine.length === 0 && (
        <p className="px-2 text-center text-sm text-pretty" style={{ color: 'var(--muted)' }}>
          You have not registered any IP yet. Register work you created or own and sites that use it can pay you per use.
        </p>
      )}

      {mine.map((d) => (
        <OwnedCard key={d.id.toString()} asset={d} />
      ))}
    </div>
  )
}

function OwnedCard({ asset: d }: { asset: AssetView }) {
  const { writeContractAsync } = useWriteContract()
  const { send, status, hash, error } = useSend()
  const [price, setPrice] = useState('')
  const [editing, setEditing] = useState(false)
  const [evidence, setEvidence] = useState('')
  const [evidenceFile, setEvidenceFile] = useState('')
  const [noticeUri, setNoticeUri] = useState('')

  const registry = REGISTRY_ADDRESS
  const claim = () => {
    if (!registry) return
    void send(
      () =>
        writeContractAsync({ address: registry, abi: registryAbi, functionName: 'claim', args: [d.id], chainId: CHAIN_ID }),
      'Royalties sent to your wallet',
    )
  }
  const updatePrice = (value: bigint) => {
    if (!registry) return
    void send(
      () =>
        writeContractAsync({
          address: registry,
          abi: registryAbi,
          functionName: 'setPrice',
          args: [d.id, value],
          chainId: CHAIN_ID,
        }),
      'Price updated',
    )
  }
  const recordNotice = async () => {
    if (!registry || !HASH_RE.test(evidence)) return
    const ok = await send(
      () =>
        writeContractAsync({
          address: registry,
          abi: registryAbi,
          functionName: 'recordNotice',
          args: [d.id, evidence as `0x${string}`, noticeUri.trim()],
          chainId: CHAIN_ID,
        }),
      'Notice recorded onchain',
    )
    if (ok) {
      setEvidence('')
      setEvidenceFile('')
      setNoticeUri('')
    }
  }
  const toggleActive = () => {
    if (!registry) return
    void send(
      () =>
        writeContractAsync({
          address: registry,
          abi: registryAbi,
          functionName: 'setActive',
          args: [d.id, !d.active],
          chainId: CHAIN_ID,
        }),
      d.active ? 'Paused new payments' : 'Accepting payments',
    )
  }

  let newPrice: bigint | null = null
  try {
    newPrice = price.trim() ? parseUsdc(price) : null
  } catch {
    newPrice = null
  }

  return (
    <section className="rounded-3xl p-5 glass-card">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>
            {kindLabel(d.kind)} · #{d.id.toString()} · {shortAddress(d.contentHash)}
          </div>
          {!d.transferable && (
            <div className="mt-0.5 text-[11px] font-semibold" style={{ color: 'var(--accent-hover)' }}>
              Locked to your wallet. Only you can manage this.
            </div>
          )}
          <h3 className="mt-0.5 break-words text-base font-semibold text-balance">{d.uri}</h3>
        </div>
        <span
          className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold"
          style={{
            background: d.active ? 'rgba(26,128,71,0.1)' : 'rgba(107,101,128,0.12)',
            color: d.active ? 'var(--success)' : 'var(--muted)',
          }}
        >
          {d.active ? 'Open' : 'Paused'}
        </span>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        <Mini label="Per use" value={fmtUsdc(d.pricePerUse)} />
        <Mini label="Uses paid" value={d.totalUses.toLocaleString()} />
        <Mini label="Unclaimed" value={fmtUsdc(d.unclaimed)} />
      </div>

      <div className="mt-4 flex gap-2">
        <div className="flex-1">
          <TxButton
            label={`Claim ${fmtUsdc(d.unclaimed)}`}
            onClick={claim}
            status={status}
            disabled={d.unclaimed === 0n}
          />
        </div>
        <button
          onClick={() => setEditing((v) => !v)}
          className="min-h-11 rounded-2xl px-4 text-sm font-semibold glass-inner"
        >
          Manage
        </button>
      </div>

      {editing && (
        <div className="mt-3 space-y-3 rounded-2xl p-3 glass-inner">
          <div className="flex gap-2">
            <input
              inputMode="decimal"
              value={price}
              onChange={(e) => {
                const v = e.target.value.replace(/[^0-9.]/g, '')
                if (/^\d*\.?\d{0,6}$/.test(v)) setPrice(v)
              }}
              placeholder={`New price (now ${fmtUsdc(d.pricePerUse)})`}
              aria-label="New price per use in USDC"
              className="field min-h-11 w-full rounded-xl bg-white/70 px-3 text-sm tabular-nums outline-none"
              style={{ border: '1px solid var(--border)' }}
            />
            <button
              disabled={newPrice === null || newPrice === d.pricePerUse}
              onClick={() => newPrice !== null && updatePrice(newPrice)}
              className="min-h-11 shrink-0 rounded-xl px-4 text-sm font-semibold disabled:opacity-40"
              style={{ background: 'var(--accent)', color: '#fff' }}
            >
              Set
            </button>
          </div>
          <button
            onClick={toggleActive}
            className="min-h-11 w-full rounded-xl text-sm font-semibold"
            style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
          >
            {d.active ? 'Pause new payments' : 'Resume payments'}
          </button>

          <div className="space-y-2 border-t pt-3" style={{ borderColor: 'var(--border)' }}>
            <div className="text-xs font-semibold">Record unauthorized use</div>
            <p className="text-[11px] text-pretty" style={{ color: 'var(--muted)' }}>
              Publishes a dated notice with the fingerprint of your evidence. It is your own unverified statement and does
              not stop anyone by itself. Keep names and personal details out of it.
            </p>
            <label className="flex min-h-11 cursor-pointer items-center gap-2 rounded-xl bg-white/60 px-3 text-xs">
              <span className="min-w-0 truncate">{evidenceFile || 'Choose evidence file to fingerprint'}</span>
              <input
                type="file"
                className="sr-only"
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (!f) return
                  void sha256Hex(f).then((h) => {
                    setEvidence(h)
                    setEvidenceFile(f.name)
                  })
                }}
              />
            </label>
            <input
              value={noticeUri}
              onChange={(e) => setNoticeUri(e.target.value)}
              placeholder="Link to notice or filing (optional)"
              aria-label="Link to notice or filing"
              className="field min-h-11 w-full rounded-xl bg-white/70 px-3 text-sm outline-none"
              style={{ border: '1px solid var(--border)' }}
            />
            <button
              disabled={!HASH_RE.test(evidence) || new TextEncoder().encode(noticeUri).length > 256}
              onClick={() => {
                void recordNotice()
              }}
              className="min-h-11 w-full rounded-xl text-sm font-semibold disabled:opacity-40"
              style={{ background: 'var(--accent)', color: '#fff' }}
            >
              Record notice
            </button>
            {d.noticeCount > 0n && (
              <p className="text-[11px]" style={{ color: 'var(--muted)' }}>
                {d.noticeCount.toString()} notice{d.noticeCount === 1n ? '' : 's'} recorded so far.
              </p>
            )}
          </div>
        </div>
      )}
      <TxReceipt status={status} hash={hash} error={error} />
    </section>
  )
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl px-2 py-2.5 glass-inner">
      <div className="display text-sm font-bold tabular-nums">{value}</div>
      <div className="text-[10px] uppercase" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
        {label}
      </div>
    </div>
  )
}
