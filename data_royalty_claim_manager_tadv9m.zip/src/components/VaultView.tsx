import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import { Download, FileLock2, Fingerprint, FolderDown, Loader2, LockKeyhole, ShieldCheck, Trash2, Upload } from 'lucide-react'
import type { Hex } from 'viem'
import {
  addPasskeySlot,
  copyFormat,
  decryptLegacyCopy,
  decryptWithKey,
  encryptWithKey,
  removePasskeySlot,
  VaultError,
  type Profile,
} from '@/lib/vaultCrypto'
import { BiometricError, biometricSupported, enrollBiometric } from '@/lib/biometric'
import { loadProfile, saveProfile } from '@/lib/vaultProfile'
import { VaultLock } from './VaultLock'
import { RequestTracker } from './RequestTracker'
import { GovApiTool } from './GovApiTool'
import { deleteItem, listItems, markBackedUp, putItem, type VaultItem } from '@/lib/vaultStore'

interface VaultViewProps {
  onRegister: (fingerprint: Hex, label: string) => void
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

function safeName(label: string): string {
  return label.replace(/[^\w.-]+/g, '_').slice(0, 60) || 'vault-copy'
}

type FolderHandle = {
  getFileHandle: (
    name: string,
    options: { create: boolean },
  ) => Promise<{ createWritable: () => Promise<{ write: (data: Blob) => Promise<void>; close: () => Promise<void> }> }>
}
type FolderPicker = (options?: { mode?: 'readwrite' }) => Promise<FolderHandle>

/** Folder access exists in Chromium browsers only. Elsewhere, downloads are the fallback. */
function getFolderPicker(): FolderPicker | undefined {
  return (window as unknown as { showDirectoryPicker?: FolderPicker }).showDirectoryPicker?.bind(window)
}

function sizeLabel(bytes: number): string {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

interface UnlockedProps extends VaultViewProps {
  profile: Profile
  sessionKey: CryptoKey
  onProfile: (profile: Profile) => void
  onLock: () => void
}

function VaultUnlocked({ profile, sessionKey, onProfile, onLock, onRegister }: UnlockedProps) {
  const [items, setItems] = useState<VaultItem[]>([])
  const [label, setLabel] = useState('')
  const [busy, setBusy] = useState(false)
  const [loadError, setLoadError] = useState(false)
  const pickFolder = getFolderPicker()

  const refresh = useCallback(async () => {
    try {
      setItems(await listItems())
      setLoadError(false)
    } catch {
      setLoadError(true)
    }
  }, [])

  useEffect(() => {
    let active = true
    listItems()
      .then((found) => {
        if (active) setItems(found)
      })
      .catch(() => {
        if (active) setLoadError(true)
      })
    return () => {
      active = false
    }
  }, [])

  const guard = async (work: () => Promise<void>) => {
    setBusy(true)
    try {
      await work()
    } catch (err) {
      toast.error(
        err instanceof VaultError || err instanceof BiometricError ? err.message : 'That did not work. Please try again.',
      )
    } finally {
      setBusy(false)
    }
  }

  /** Opens a copy with the unlocked key. Older single-passphrase copies ask for their passphrase. */
  const openCopy = async (blob: Blob) => {
    if ((await copyFormat(blob)) === 'v1') {
      const phrase = window.prompt('This is an older copy. Enter the passphrase it was encrypted with:')
      if (!phrase) throw new VaultError('Cancelled.')
      return decryptLegacyCopy(blob, phrase)
    }
    return decryptWithKey(blob, sessionKey)
  }

  const enroll = () =>
    void guard(async () => {
      const { credentialId, prfSalt, secret } = await enrollBiometric()
      onProfile(await addPasskeySlot(profile, sessionKey, secret, credentialId, prfSalt))
      toast.success('Fingerprint or face unlock is on. New encrypted copies will carry it.')
    })

  const disableBiometric = () => {
    if (!window.confirm('Turn off fingerprint and face unlock? Your recovery key will still open the vault.')) return
    onProfile(removePasskeySlot(profile))
    toast.success('Fingerprint and face unlock turned off.')
  }

  const addFile = (file: File | undefined) => {
    if (!file) return
    void guard(async () => {
      const { blob, fingerprint, size } = await encryptWithKey(file, sessionKey, profile)
      await putItem({
        id: crypto.randomUUID(),
        label: label.trim() || 'Untitled work',
        size,
        createdAt: Date.now(),
        fingerprint,
        encrypted: blob,
      })
      setLabel('')
      await refresh()
      toast.success('Encrypted and saved. Download a copy to keep elsewhere.')
    })
  }

  /** Encrypts a file produced inside the app (such as a government record) into the vault. */
  const saveResult = async (file: File, itemLabel: string) => {
    const { blob, fingerprint, size } = await encryptWithKey(file, sessionKey, profile)
    await putItem({
      id: crypto.randomUUID(),
      label: itemLabel,
      size,
      createdAt: Date.now(),
      fingerprint,
      encrypted: blob,
    })
    await refresh()
  }

  const importCopy = (file: File | undefined) => {
    if (!file) return
    void guard(async () => {
      const opened = await openCopy(file)
      await putItem({
        id: crypto.randomUUID(),
        label: label.trim() || file.name.replace(/\.ipvault$/, ''),
        size: opened.blob.size,
        createdAt: Date.now(),
        fingerprint: opened.fingerprint,
        encrypted: file,
      })
      setLabel('')
      await refresh()
      toast.success('Encrypted copy restored.')
    })
  }

  const unlock = (item: VaultItem) =>
    void guard(async () => {
      const opened = await openCopy(item.encrypted)
      download(opened.blob, opened.name)
    })

  const downloadCopy = (item: VaultItem) => {
    download(item.encrypted, `${safeName(item.label)}.ipvault`)
    void markBackedUp(item).then(refresh)
  }

  const saveToFolder = (item: VaultItem) => {
    if (!pickFolder) return
    void guard(async () => {
      try {
        const folder = await pickFolder({ mode: 'readwrite' })
        const handle = await folder.getFileHandle(`${safeName(item.label)}.ipvault`, { create: true })
        const writable = await handle.createWritable()
        await writable.write(item.encrypted)
        await writable.close()
      } catch (err) {
        if ((err as { name?: string }).name === 'AbortError') return
        throw new VaultError('Could not write to that folder. Choose another one.')
      }
      await markBackedUp(item)
      await refresh()
      toast.success('Encrypted copy saved to your folder.')
    })
  }

  const checkBackup = (file: File | undefined) => {
    if (!file) return
    void guard(async () => {
      const opened = await openCopy(file)
      const match = items.find((i) => i.fingerprint === opened.fingerprint)
      toast.success(
        match
          ? `Backup is good. It matches "${match.label}".`
          : 'Backup opens correctly with your vault key. It is not in this vault.',
      )
    })
  }

  const remove = (item: VaultItem) => {
    if (!window.confirm(`Delete "${item.label}" from this browser? Make sure you downloaded an encrypted copy first.`)) return
    void deleteItem(item.id).then(refresh)
  }

  return (
    <div className="space-y-4">
      <section className="rounded-3xl p-5 glass-card">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <FileLock2 className="size-5" />
            <h2 className="display text-lg font-semibold">Private vault</h2>
          </div>
          <button
            onClick={onLock}
            className="flex min-h-11 items-center gap-1.5 rounded-xl px-3 text-xs font-semibold glass-inner"
          >
            <LockKeyhole className="size-3.5" /> Lock now
          </button>
        </div>
        <p className="mt-1.5 text-sm text-pretty" style={{ color: 'var(--muted)' }}>
          Unlocked. Your files are encrypted on this device and nothing is uploaded. The vault locks again when you leave
          this tab or reload the page.
        </p>

        <div className="mt-4 rounded-2xl p-4 glass-inner">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Fingerprint className="size-4" />
            {profile.passkey ? 'Fingerprint or face unlock is on' : 'Fingerprint or face unlock'}
          </div>
          {profile.passkey ? (
            <>
              <p className="mt-1 text-xs text-pretty" style={{ color: 'var(--muted)' }}>
                Your device checks you, and the app never sees your fingerprint or face. Your paper recovery key still
                works if the device or the biometric is ever unavailable.
              </p>
              <button onClick={disableBiometric} className="mt-2 min-h-11 text-xs font-semibold underline">
                Turn it off
              </button>
            </>
          ) : biometricSupported() ? (
            <>
              <p className="mt-1 text-xs text-pretty" style={{ color: 'var(--muted)' }}>
                Use your device fingerprint or face to open the vault. Your paper recovery key stays as the backup. Set
                this up on the address where you will use the app, since passkeys only work on the address they were made on.
              </p>
              <button
                onClick={enroll}
                disabled={busy}
                className="mt-2 min-h-11 w-full rounded-xl text-sm font-semibold disabled:opacity-40"
                style={{ background: 'var(--accent)', color: '#fff' }}
              >
                Add fingerprint or face unlock
              </button>
            </>
          ) : (
            <p className="mt-1 text-xs text-pretty" style={{ color: 'var(--muted)' }}>
              This browser cannot do fingerprint or face unlock. Your recovery key opens the vault.
            </p>
          )}
        </div>

        <label className="mt-4 block">
          <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Neutral label (stored on this device, not encrypted)
          </span>
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value.slice(0, 80))}
            placeholder="e.g. Research volume 1"
            className="field mt-1 min-h-11 w-full rounded-2xl px-3 text-sm outline-none glass-inner"
          />
        </label>

        <div className="mt-4 grid grid-cols-2 gap-2">
          <FilePick label="Encrypt a file" icon={<Upload className="size-4" />} disabled={busy} onFile={addFile} />
          <FilePick label="Restore a copy" icon={<Download className="size-4" />} disabled={busy} onFile={importCopy} />
          <div className="col-span-2">
            <FilePick
              label="Check a backup file"
              icon={<ShieldCheck className="size-4" />}
              disabled={busy}
              onFile={checkBackup}
            />
          </div>
        </div>
        {busy && (
          <p className="mt-3 flex items-center gap-2 text-xs" style={{ color: 'var(--muted)' }}>
            <Loader2 className="size-3.5 animate-spin" /> Working on your device...
          </p>
        )}
      </section>

      <RequestTracker sessionKey={sessionKey} />

      <GovApiTool sessionKey={sessionKey} onSave={saveResult} />

      <section className="rounded-3xl p-5 text-sm glass-card">
        <h3 className="display font-semibold">Keeping it safe</h3>
        <ul className="mt-2 list-disc space-y-1.5 pl-5 text-pretty" style={{ color: 'var(--muted)' }}>
          <li>This browser can clear its storage. Always download an encrypted copy.</li>
          <li>Keep at least two encrypted copies in different places you control, such as drives you own.</li>
          <li>Use a generated recovery key rather than a phrase someone could guess, and keep the paper offline.</li>
          <li>A trusted person can hold an encrypted copy for you. Without your key they cannot read it.</li>
          <li>
            Email is not a vault. Never send your recovery key or an unencrypted file by email, including through mail
            apps such as Superhuman. An encrypted .ipvault copy is safe to attach as an extra backup.
          </li>
          <li>Anyone who can use this device while it is unlocked, or who has your recovery key, can open your files. A fingerprint or face cannot be changed if it is ever compromised, so keep the recovery key safe too.</li>
          <li>Encrypt a work, then register its fingerprint before you share it with anyone.</li>
        </ul>
      </section>

      <section className="rounded-3xl p-5 text-sm glass-card">
        <h3 className="display font-semibold">Using your Proton account</h3>
        <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-pretty" style={{ color: 'var(--muted)' }}>
          <li>Encrypt the file here first. It is locked before it ever leaves this device.</li>
          <li>
            {pickFolder
              ? 'Press "Save to a folder I choose" and pick your Proton Drive folder, if you use the Proton Drive desktop app. It syncs on its own.'
              : 'This browser cannot save straight to a folder. Press "Download encrypted" instead.'}
          </li>
          <li>Otherwise, open Proton Drive in your browser and upload the downloaded .ipvault file.</li>
          <li>Keep your recovery key on paper, not in the same Proton account as the encrypted files.</li>
        </ol>
        <p className="mt-2 text-xs text-pretty" style={{ color: 'var(--subtle)' }}>
          Because the files are encrypted here with a key Proton never sees, they stay unreadable even if an account is
          ever accessed by someone else.
        </p>
        <p className="mt-2 text-xs text-pretty" style={{ color: 'var(--subtle)' }}>
          Do not rely on text-message codes. A phone number can be taken over through a SIM swap or a carrier account.
          Prefer a hardware security key or passkey, or an authenticator app. Where an account lets you, remove the
          phone number from sign-in and recovery, and keep the account's recovery codes on paper.
        </p>
      </section>

      {loadError && (
        <p className="text-xs" style={{ color: 'var(--danger)' }}>
          This browser is blocking private storage. Encrypted copies cannot be kept here, so use another browser window.
        </p>
      )}

      {items.map((item) => (
        <section key={item.id} className="rounded-3xl p-5 glass-card">
          <h3 className="break-words text-base font-semibold">{item.label}</h3>
          <p className="mt-0.5 text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>
            {sizeLabel(item.size)} · {new Date(item.createdAt).toLocaleDateString()}
          </p>
          <p className="mono mt-2 break-all text-[10px]" style={{ color: 'var(--subtle)' }}>
            {item.fingerprint}
          </p>
          <p
            className="mt-2 text-xs font-semibold"
            style={{ color: item.backedUpAt ? 'var(--success)' : 'var(--danger)' }}
          >
            {item.backedUpAt
              ? `Copy saved outside this browser on ${new Date(item.backedUpAt).toLocaleDateString()}`
              : 'Not backed up yet. This browser could lose it.'}
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              onClick={() => downloadCopy(item)}
              className="min-h-11 rounded-xl text-sm font-semibold glass-inner"
            >
              Download encrypted
            </button>
            <button
              onClick={() => unlock(item)}
              disabled={busy}
              className="min-h-11 rounded-xl text-sm font-semibold glass-inner disabled:opacity-40"
            >
              Unlock original
            </button>
            {pickFolder && (
              <button
                onClick={() => saveToFolder(item)}
                disabled={busy}
                className="col-span-2 flex min-h-11 items-center justify-center gap-2 rounded-xl text-sm font-semibold glass-inner disabled:opacity-40"
              >
                <FolderDown className="size-4" /> Save to a folder I choose (drive, USB)
              </button>
            )}
            <button
              onClick={() => onRegister(item.fingerprint, item.label)}
              className="min-h-11 rounded-xl text-sm font-semibold"
              style={{ background: 'var(--accent)', color: '#fff' }}
            >
              Register as IP
            </button>
            <button
              onClick={() => remove(item)}
              aria-label={`Delete ${item.label}`}
              className="flex min-h-11 items-center justify-center gap-1.5 rounded-xl text-sm font-semibold glass-inner"
              style={{ color: 'var(--danger)' }}
            >
              <Trash2 className="size-4" /> Delete
            </button>
          </div>
        </section>
      ))}
    </div>
  )
}

function FilePick({
  label,
  icon,
  disabled,
  onFile,
}: {
  label: string
  icon: React.ReactNode
  disabled: boolean
  onFile: (file: File | undefined) => void
}) {
  return (
    <label
      className="flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-2xl px-3 text-sm font-semibold transition-all"
      style={{
        background: 'var(--accent)',
        color: '#fff',
        opacity: disabled ? 0.4 : 1,
        pointerEvents: disabled ? 'none' : 'auto',
      }}
    >
      {icon} {label}
      <input
        type="file"
        className="sr-only"
        disabled={disabled}
        onChange={(e) => {
          onFile(e.target.files?.[0])
          e.target.value = ''
        }}
      />
    </label>
  )
}

export function VaultView({ onRegister }: VaultViewProps) {
  const [profile, setProfile] = useState<Profile | null>(loadProfile)
  const [sessionKey, setSessionKey] = useState<CryptoKey | null>(null)

  if (!profile || !sessionKey) {
    return (
      <VaultLock
        profile={profile}
        onUnlocked={(unlocked, key) => {
          setProfile(unlocked)
          setSessionKey(key)
        }}
      />
    )
  }

  return (
    <VaultUnlocked
      profile={profile}
      sessionKey={sessionKey}
      onProfile={(next) => {
        saveProfile(next)
        setProfile(next)
      }}
      onLock={() => setSessionKey(null)}
      onRegister={onRegister}
    />
  )
}
