import { useEffect, useMemo, useState } from 'react'
import { erc20Abi, keccak256, stringToHex } from 'viem'
import { useAccount, useReadContract, useWriteContract } from 'wagmi'
import { CHAIN_ID, REGISTRY_ADDRESS, USDC_ADDRESS, kindLabel, registryAbi, type AssetView } from '@/contracts/registry'
import { useSend } from '@/hooks/useSend'
import { fmtUsdc } from '@/lib/format'
import { Sheet } from './Sheet'
import { TxButton, TxReceipt } from './TxButton'

interface PaySheetProps {
  asset: AssetView | null
  onClose: () => void
}

export function PaySheet({ asset, onClose }: PaySheetProps) {
  const { address } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const { send, status, hash, error, reset } = useSend()
  const [uses, setUses] = useState('1000')
  const [label, setLabel] = useState('')

  useEffect(() => {
    reset()
    setUses('1000')
    setLabel('')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [asset?.id])

  const usesN = /^\d{1,12}$/.test(uses) ? BigInt(uses) : 0n
  const price = asset?.pricePerUse ?? 0n
  const total = usesN * price

  const { data: allowance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'allowance',
    args: address && REGISTRY_ADDRESS ? [address, REGISTRY_ADDRESS] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address && !!REGISTRY_ADDRESS && !!asset },
  })
  const { data: balance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address && !!asset },
  })

  const needsApproval = useMemo(() => (allowance ?? 0n) < total, [allowance, total])
  const insufficient = balance !== undefined && balance < total
  const unavailable = !asset?.active || price === 0n
  const invalid = usesN === 0n || label.trim().length === 0 || unavailable || insufficient

  const approve = async () => {
    const registry = REGISTRY_ADDRESS
    if (!registry) return
    reset()
    await send(
      () =>
        writeContractAsync({
          address: USDC_ADDRESS,
          abi: erc20Abi,
          functionName: 'approve',
          args: [registry, total],
          chainId: CHAIN_ID,
        }),
      'USDC approved',
    )
  }

  const pay = async () => {
    const registry = REGISTRY_ADDRESS
    if (!registry || !asset) return
    reset()
    const ok = await send(
      () =>
        writeContractAsync({
          address: registry,
          abi: registryAbi,
          functionName: 'payForUsage',
          args: [asset.id, usesN, asset.pricePerUse, keccak256(stringToHex(label.trim()))],
          chainId: CHAIN_ID,
        }),
      'Royalty paid',
    )
    if (ok) setLabel('')
  }

  return (
    <Sheet open={asset !== null} onClose={onClose} title="Pay royalties for IP use">
      {asset && (
        <div className="space-y-4">
          <div className="rounded-2xl p-4 glass-inner">
            <div className="text-xs" style={{ color: 'var(--muted)' }}>
              IP #{asset.id.toString()}
            </div>
            <div className="mt-0.5 break-all text-sm font-semibold">{asset.uri}</div>
            <div className="mt-1 text-xs" style={{ color: 'var(--muted)' }}>
              {kindLabel(asset.kind)}
              {asset.licenseUri && (
                <>
                  {' · '}
                  <span className="break-all">License: {asset.licenseUri}</span>
                </>
              )}
            </div>
            <div className="mt-2 text-xs tabular-nums" style={{ color: 'var(--muted)' }}>
              {unavailable ? 'Not accepting payments' : `${fmtUsdc(price)} USDC per use`}
            </div>
          </div>

          <label className="block">
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              How many times did your site use this work?
            </span>
            <div className="field mt-1 rounded-2xl p-3 glass-inner">
              <input
                inputMode="numeric"
                value={uses}
                onChange={(e) => setUses(e.target.value.replace(/\D/g, ''))}
                className="display w-full bg-transparent text-3xl font-bold tabular-nums outline-none"
                aria-label="Number of uses"
              />
            </div>
          </label>

          <label className="block">
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              What did it improve? (recorded onchain as a hash)
            </span>
            <input
              value={label}
              onChange={(e) => setLabel(e.target.value.slice(0, 120))}
              placeholder="e.g. homepage search ranking v3"
              className="field mt-1 w-full rounded-2xl px-3 py-3 text-sm outline-none glass-inner"
            />
          </label>

          <div className="space-y-1 rounded-2xl p-4 text-sm glass-inner">
            <div className="flex justify-between">
              <span style={{ color: 'var(--muted)' }}>Total royalty</span>
              <span className="display font-bold tabular-nums">{fmtUsdc(total)} USDC</span>
            </div>
            <div className="flex justify-between text-xs" style={{ color: 'var(--subtle)' }}>
              <span>Your USDC balance</span>
              <span className="tabular-nums">{balance === undefined ? '...' : `${fmtUsdc(balance)} USDC`}</span>
            </div>
          </div>

          {insufficient && (
            <p className="text-xs" style={{ color: 'var(--danger)' }}>
              Not enough USDC. Use Get test USDC in the Arc Studio sidebar.
            </p>
          )}

          {needsApproval && !invalid ? (
            <TxButton label={`Approve ${fmtUsdc(total)} USDC`} onClick={approve} status={status} />
          ) : (
            <TxButton label={`Pay ${fmtUsdc(total)} USDC`} onClick={pay} status={status} disabled={invalid} />
          )}
          <TxReceipt status={status} hash={hash} error={error} />
        </div>
      )}
    </Sheet>
  )
}
