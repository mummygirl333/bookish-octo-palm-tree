import { useCallback, useEffect, useState } from 'react'
import type { Address, Hex } from 'viem'

export interface PendingRegistration {
  owner: Address
  commitment: Hex
  contentHash: Hex
  kind: number
  uri: string
  licenseUri: string
  /** Unix seconds as a string; "0" means unknown. */
  createdAt: string
  transferable: boolean
  /** Hash of a copyright registration document, or the zero hash for none. */
  copyrightRef: Hex
  priceRaw: string
  salt: Hex
}

const KEY = 'royalty-registry:pending-registrations:v4'

function load(): PendingRegistration[] {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? (JSON.parse(raw) as PendingRegistration[]) : []
  } catch {
    return []
  }
}

/**
 * Registrations that completed step 1 (reserve) and still need step 2 (finish).
 * Kept in this browser so a reload does not lose the secret salt.
 */
export function usePending(owner: Address | undefined) {
  const [all, setAll] = useState<PendingRegistration[]>(load)

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(all))
  }, [all])

  const add = useCallback((entry: PendingRegistration) => {
    setAll((prev) => [...prev.filter((p) => p.commitment !== entry.commitment), entry])
  }, [])

  const remove = useCallback((commitment: Hex) => {
    setAll((prev) => prev.filter((p) => p.commitment !== commitment))
  }, [])

  const mine = owner ? all.filter((p) => p.owner.toLowerCase() === owner.toLowerCase()) : []
  return { pending: mine, add, remove }
}
