import { useMemo } from 'react'
import { useReadContract } from 'wagmi'
import { CHAIN_ID, REGISTRY_ADDRESS, registryAbi, type AssetView } from '@/contracts/registry'

const PAGE = 100n

/** Reads the newest page of IP assets (up to 100) from the registry. */
export function useAssets() {
  const enabled = REGISTRY_ADDRESS !== undefined

  const count = useReadContract({
    address: REGISTRY_ADDRESS,
    abi: registryAbi,
    functionName: 'assetCount',
    chainId: CHAIN_ID,
    query: { enabled, refetchInterval: 10_000 },
  })

  const total = count.data ?? 0n
  const start = total > PAGE ? total - PAGE + 1n : 1n

  const page = useReadContract({
    address: REGISTRY_ADDRESS,
    abi: registryAbi,
    functionName: 'getAssets',
    args: [start, PAGE],
    chainId: CHAIN_ID,
    query: { enabled: enabled && total > 0n, refetchInterval: 10_000 },
  })

  const assets = useMemo<AssetView[]>(() => {
    if (!page.data) return []
    const [rows, ids] = page.data
    return rows
      .map((row, i) => ({
        id: ids[i],
        owner: row.owner,
        active: row.active,
        kind: Number(row.kind),
        pricePerUse: BigInt(row.pricePerUse),
        contentHash: row.contentHash,
        uri: row.uri,
        licenseUri: row.licenseUri,
        createdAt: BigInt(row.createdAt),
        transferable: row.transferable,
        copyrightRef: row.copyrightRef,
        noticeCount: row.noticeCount,
        registeredAt: BigInt(row.registeredAt),
        totalUses: row.totalUses,
        totalEarned: row.totalEarned,
        unclaimed: row.unclaimed,
      }))
      .reverse()
  }, [page.data])

  return {
    assets,
    total,
    isLoading: enabled && (count.isLoading || (total > 0n && page.isLoading)),
    isError: count.isError || page.isError,
  }
}
