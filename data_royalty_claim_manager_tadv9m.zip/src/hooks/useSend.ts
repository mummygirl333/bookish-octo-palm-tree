import { useCallback, useState } from 'react'
import { useAccount, usePublicClient, useSwitchChain } from 'wagmi'
import { useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import type { Hash } from 'viem'
import { CHAIN_ID } from '@/contracts/registry'
import { isUserRejection, parseOnchainError } from '@/lib/errors'

export type SendStatus = 'idle' | 'wallet' | 'confirming' | 'success' | 'error'

/**
 * Runs one onchain write end to end: switches to Arc Testnet if needed, waits for
 * the wallet, waits for the receipt, refreshes cached reads. States are real.
 */
export function useSend() {
  const { chainId } = useAccount()
  const { switchChainAsync } = useSwitchChain()
  const publicClient = usePublicClient({ chainId: CHAIN_ID })
  const queryClient = useQueryClient()
  const [status, setStatus] = useState<SendStatus>('idle')
  const [hash, setHash] = useState<Hash | undefined>()
  const [error, setError] = useState<string | undefined>()

  const reset = useCallback(() => {
    setStatus('idle')
    setHash(undefined)
    setError(undefined)
  }, [])

  const send = useCallback(
    async (write: () => Promise<Hash>, successMessage?: string): Promise<boolean> => {
      setError(undefined)
      setHash(undefined)
      try {
        if (chainId !== CHAIN_ID) await switchChainAsync({ chainId: CHAIN_ID })
        setStatus('wallet')
        const txHash = await write()
        setHash(txHash)
        setStatus('confirming')
        const receipt = await publicClient?.waitForTransactionReceipt({ hash: txHash })
        if (receipt && receipt.status !== 'success') throw new Error('reverted')
        await queryClient.invalidateQueries()
        setStatus('success')
        if (successMessage) toast.success(successMessage)
        return true
      } catch (err) {
        if (isUserRejection(err)) {
          setStatus('idle')
          return false
        }
        const message = parseOnchainError(err)
        setError(message)
        setStatus('error')
        toast.error(message)
        return false
      }
    },
    [chainId, switchChainAsync, publicClient, queryClient],
  )

  return { send, status, hash, error, reset, busy: status === 'wallet' || status === 'confirming' }
}
