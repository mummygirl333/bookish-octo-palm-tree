import type { Hex } from 'viem'

/** Encrypted copies kept in this browser (IndexedDB). Only ciphertext is stored. */
export interface VaultItem {
  id: string
  /** Local label, stored unencrypted on this device. Keep it neutral. */
  label: string
  size: number
  createdAt: number
  fingerprint: Hex
  encrypted: Blob
  /** When an encrypted copy was last saved outside this browser (download or folder). */
  backedUpAt?: number
}

const DB = 'ip-vault'
const STORE = 'items'

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB, 1)
    request.onupgradeneeded = () => request.result.createObjectStore(STORE, { keyPath: 'id' })
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(new Error('Browser storage is unavailable.'))
  })
}

async function run<T>(mode: IDBTransactionMode, action: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open()
  return new Promise<T>((resolve, reject) => {
    const request = action(db.transaction(STORE, mode).objectStore(STORE))
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(new Error('Browser storage failed.'))
  })
}

export async function listItems(): Promise<VaultItem[]> {
  const items = await run<VaultItem[]>('readonly', (s) => s.getAll() as IDBRequest<VaultItem[]>)
  return items.sort((a, b) => b.createdAt - a.createdAt)
}

export async function putItem(item: VaultItem): Promise<void> {
  await run('readwrite', (s) => s.put(item))
  await navigator.storage?.persist?.()
}

export async function markBackedUp(item: VaultItem): Promise<void> {
  await putItem({ ...item, backedUpAt: Date.now() })
}

export async function deleteItem(id: string): Promise<void> {
  await run('readwrite', (s) => s.delete(id))
}
