import { fromB64, toB64 } from './b64'

/**
 * Fingerprint or face unlock through the device passkey (WebAuthn + PRF extension).
 * The device checks her fingerprint or face. This app only receives a secret the
 * device releases after it says "verified". It never sees any biometric data.
 */

export class BiometricError extends Error {}

type PrfOutput = { prf?: { enabled?: boolean; results?: { first?: ArrayBuffer } } }

export function biometricSupported(): boolean {
  return typeof window !== 'undefined' && 'PublicKeyCredential' in window && !!navigator.credentials
}

function random(length: number): Uint8Array<ArrayBuffer> {
  return crypto.getRandomValues(new Uint8Array(length))
}

function explain(err: unknown): BiometricError {
  if (err instanceof BiometricError) return err
  const name = (err as { name?: string } | null)?.name
  if (name === 'NotAllowedError' || name === 'SecurityError') {
    return new BiometricError(
      'Fingerprint or face check was cancelled or is not allowed here. It cannot run inside the Arc Studio preview. Open the deployed app on your own address and try again.',
    )
  }
  if (name === 'NotSupportedError' || name === 'InvalidStateError') {
    return new BiometricError('This device or browser cannot do fingerprint or face unlock for the vault.')
  }
  return new BiometricError('The fingerprint or face check did not work. Please try again.')
}

/** Unlock: returns the secret for this vault, released only after the device verifies her. */
export async function unlockBiometric(credentialId: string, prfSalt: string): Promise<string> {
  try {
    const assertion = (await navigator.credentials.get({
      publicKey: {
        challenge: random(32),
        allowCredentials: [{ type: 'public-key', id: fromB64(credentialId) }],
        userVerification: 'required',
        timeout: 60_000,
        extensions: { prf: { eval: { first: fromB64(prfSalt) } } },
      },
    })) as PublicKeyCredential | null
    const first = (assertion?.getClientExtensionResults() as PrfOutput | undefined)?.prf?.results?.first
    if (!first) throw new BiometricError('This device did not release a key. Use your recovery key instead.')
    return toB64(new Uint8Array(first))
  } catch (err) {
    throw explain(err)
  }
}

/** Set up: creates a passkey on this device and returns its id, salt and first secret. */
export async function enrollBiometric(): Promise<{ credentialId: string; prfSalt: string; secret: string }> {
  try {
    const created = (await navigator.credentials.create({
      publicKey: {
        challenge: random(32),
        rp: { name: 'IP Vault' },
        user: { id: random(16), name: 'ip-vault', displayName: 'My IP vault' },
        pubKeyCredParams: [
          { type: 'public-key', alg: -7 },
          { type: 'public-key', alg: -257 },
        ],
        authenticatorSelection: { userVerification: 'required', residentKey: 'preferred' },
        timeout: 60_000,
        extensions: { prf: {} },
      },
    })) as PublicKeyCredential | null
    if (!created) throw new BiometricError('No passkey was created.')
    const prf = (created.getClientExtensionResults() as PrfOutput).prf
    if (!prf?.enabled) {
      throw new BiometricError('This device or browser cannot make a fingerprint or face key for the vault.')
    }
    const credentialId = toB64(new Uint8Array(created.rawId))
    const prfSalt = toB64(random(32))
    const secret = await unlockBiometric(credentialId, prfSalt)
    return { credentialId, prfSalt, secret }
  } catch (err) {
    throw explain(err)
  }
}
