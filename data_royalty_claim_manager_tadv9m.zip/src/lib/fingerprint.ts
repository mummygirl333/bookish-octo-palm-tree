import { bytesToHex, type Hex } from 'viem'

export const HASH_RE = /^0x[0-9a-fA-F]{64}$/

/** SHA-256 of raw bytes, as a 0x-prefixed hex string. */
export async function sha256Bytes(bytes: Uint8Array<ArrayBuffer>): Promise<Hex> {
  const digest = await crypto.subtle.digest('SHA-256', bytes)
  return bytesToHex(new Uint8Array(digest))
}

/** SHA-256 of a file, computed in the browser. The file is never uploaded. */
export async function sha256Hex(file: File): Promise<Hex> {
  return sha256Bytes(new Uint8Array(await file.arrayBuffer()))
}
