export class GovApiError extends Error {}

const MAX_BODY_CHARS = 2_000_000
const TIMEOUT_MS = 20_000

/**
 * The key is only ever sent to a secure .gov address on the standard port.
 * Redirects are refused, so a response can never forward the key somewhere else.
 */
export function parseTarget(text: string): URL {
  let url: URL
  try {
    url = new URL(text.trim())
  } catch {
    throw new GovApiError('Enter a full web address that starts with https://')
  }
  if (url.protocol !== 'https:') throw new GovApiError('Only secure https:// addresses are allowed.')
  if (!url.hostname.endsWith('.gov')) {
    throw new GovApiError('Your key is only sent to .gov addresses. This address is not one.')
  }
  if (url.username || url.password || url.port) {
    throw new GovApiError('Remove the login details or port number from the address.')
  }
  if (url.searchParams.has('api_key')) throw new GovApiError('Do not put the key in the address. It is added for you.')
  return url
}

/** One "name=value" per line. */
export function parseParams(text: string): Array<[string, string]> {
  const out: Array<[string, string]> = []
  for (const line of text.split('\n')) {
    const trimmed = line.trim()
    if (!trimmed) continue
    const at = trimmed.indexOf('=')
    if (at < 1) throw new GovApiError(`"${trimmed}" is not in the form name=value.`)
    const name = trimmed.slice(0, at).trim()
    if (name.toLowerCase() === 'api_key') throw new GovApiError('Do not enter the key as a parameter. It is added for you.')
    out.push([name, trimmed.slice(at + 1).trim()])
  }
  return out
}

export interface GovResult {
  status: number
  ok: boolean
  contentType: string
  body: string
  truncated: boolean
  /** The address that was called, without the key. */
  address: string
}

export async function runGovRequest(options: {
  target: URL
  params: Array<[string, string]>
  apiKey: string
  keyInHeader: boolean
}): Promise<GovResult> {
  const url = new URL(options.target.toString())
  for (const [name, value] of options.params) url.searchParams.append(name, value)
  const address = url.toString()

  const headers: Record<string, string> = { Accept: 'application/json, text/plain;q=0.9, */*;q=0.5' }
  if (options.keyInHeader) headers['X-Api-Key'] = options.apiKey
  else url.searchParams.set('api_key', options.apiKey)

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS)
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers,
      redirect: 'error',
      credentials: 'omit',
      referrerPolicy: 'no-referrer',
      signal: controller.signal,
    })
    const text = await response.text()
    return {
      status: response.status,
      ok: response.ok,
      contentType: response.headers.get('content-type') ?? '',
      body: text.slice(0, MAX_BODY_CHARS),
      truncated: text.length > MAX_BODY_CHARS,
      address,
    }
  } catch (err) {
    if ((err as { name?: string }).name === 'AbortError') throw new GovApiError('The agency took too long to answer.')
    throw new GovApiError(
      'The request could not be completed. The agency may not allow requests from a web page, may have redirected it, or may be down.',
    )
  } finally {
    clearTimeout(timer)
  }
}

export function prettyBody(result: GovResult): string {
  if (result.contentType.includes('json')) {
    try {
      return JSON.stringify(JSON.parse(result.body), null, 2)
    } catch {
      return result.body
    }
  }
  return result.body
}
