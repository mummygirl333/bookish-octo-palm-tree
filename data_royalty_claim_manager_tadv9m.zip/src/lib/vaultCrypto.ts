import type { Hex } from 'viem'
import { fromB64, toB64 } from './b64'
import { sha256Bytes } from './fingerprint'
import { RECOVERY_KEY_RE } from './recoveryKey'

/**
 * Browser-only encryption (Web Crypto). Nothing here is sent anywhere.
 *
 * One random master key encrypts every file. The master key is stored wrapped
 * ("slots"), each slot opened by a different secret:
 *   recovery slot : the paper recovery key (always present)
 *   passkey slot  : a secret released by the device's fingerprint or face (optional)
 *
 * IPV2 copy: "IPV2" | headerLength (4) | header JSON | AES-GCM(metaLength | meta | file)
 * The header carries the slots, so any copy restores on a new device with the recovery key.
 * IPV1 copies (single passphrase, older format) can still be opened.
 */

const MAGIC_V1 = new TextEncoder().encode('IPV1')
const MAGIC_V2 = new TextEncoder().encode('IPV2')
const SALT_BYTES = 16
const IV_BYTES = 12
const ITERATIONS = 600_000
export const MIN_PASSPHRASE = 12
export const MAX_FILE_BYTES = 100 * 1024 * 1024

export class VaultError extends Error {}

export interface Slot {
  salt: string
  iv: string
  wrapped: string
}

export interface Profile {
  v: 2
  recovery: Slot
  passkey?: Slot
  credentialId?: string
  prfSalt?: string
}

interface Meta {
  name: string
  type: string
}

interface Header extends Omit<Profile, 'v'> {
  v: 2
  iv: string
}

export interface EncryptedCopy {
  blob: Blob
  /** SHA-256 of the ORIGINAL file. This is what gets registered. */
  fingerprint: Hex
  size: number
}

export interface DecryptedFile {
  blob: Blob
  name: string
  fingerprint: Hex
}

function random(length: number): Uint8Array<ArrayBuffer> {
  return crypto.getRandomValues(new Uint8Array(length))
}

/** A generated recovery key is case-insensitive, so a key copied from paper still works. */
function normalize(secret: string): string {
  return RECOVERY_KEY_RE.test(secret) ? secret.toUpperCase() : secret
}

async function deriveKey(secret: string, salt: Uint8Array<ArrayBuffer>): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(normalize(secret)), 'PBKDF2', false, [
    'deriveKey',
  ])
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: ITERATIONS, hash: 'SHA-256' },
    base,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  )
}

async function wrap(masterRaw: Uint8Array<ArrayBuffer>, secret: string): Promise<Slot> {
  const salt = random(SALT_BYTES)
  const iv = random(IV_BYTES)
  const kek = await deriveKey(secret, salt)
  const wrapped = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, kek, masterRaw))
  return { salt: toB64(salt), iv: toB64(iv), wrapped: toB64(wrapped) }
}

async function unwrap(slot: Slot, secret: string): Promise<CryptoKey> {
  try {
    const kek = await deriveKey(secret, fromB64(slot.salt))
    const raw = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(slot.iv) }, kek, fromB64(slot.wrapped))
    return await crypto.subtle.importKey('raw', raw, 'AES-GCM', true, ['encrypt', 'decrypt'])
  } catch {
    throw new VaultError('Wrong key, or the copy is damaged.')
  }
}

/** Create a new vault. The recovery key is required and is the permanent way back in. */
export async function createProfile(recoveryKey: string): Promise<{ profile: Profile; key: CryptoKey }> {
  if (recoveryKey.length < MIN_PASSPHRASE) {
    throw new VaultError(`Your recovery key must be at least ${MIN_PASSPHRASE} characters.`)
  }
  const raw = random(32)
  const key = await crypto.subtle.importKey('raw', raw, 'AES-GCM', true, ['encrypt', 'decrypt'])
  return { profile: { v: 2, recovery: await wrap(raw, recoveryKey) }, key }
}

export function unlockWithRecovery(profile: Profile, recoveryKey: string): Promise<CryptoKey> {
  return unwrap(profile.recovery, recoveryKey)
}

export function unlockWithPasskey(profile: Profile, secret: string): Promise<CryptoKey> {
  if (!profile.passkey) throw new VaultError('Fingerprint or face unlock is not set up.')
  return unwrap(profile.passkey, secret)
}

export async function addPasskeySlot(
  profile: Profile,
  key: CryptoKey,
  secret: string,
  credentialId: string,
  prfSalt: string,
): Promise<Profile> {
  const raw = new Uint8Array(await crypto.subtle.exportKey('raw', key))
  return { ...profile, passkey: await wrap(raw, secret), credentialId, prfSalt }
}

export function removePasskeySlot(profile: Profile): Profile {
  return { v: 2, recovery: profile.recovery }
}

function plainText(content: Uint8Array<ArrayBuffer>, file: File): Uint8Array<ArrayBuffer> {
  const meta = new TextEncoder().encode(JSON.stringify({ name: file.name, type: file.type } satisfies Meta))
  const plain = new Uint8Array(4 + meta.length + content.length)
  new DataView(plain.buffer).setUint32(0, meta.length)
  plain.set(meta, 4)
  plain.set(content, 4 + meta.length)
  return plain
}

export async function encryptWithKey(file: File, key: CryptoKey, profile: Profile): Promise<EncryptedCopy> {
  if (file.size > MAX_FILE_BYTES) throw new VaultError('This file is larger than 100 MB.')
  const content = new Uint8Array(await file.arrayBuffer())
  const fingerprint = await sha256Bytes(content)
  const iv = random(IV_BYTES)
  const cipher = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plainText(content, file)))

  const header: Header = { ...profile, iv: toB64(iv) }
  const headerBytes = new TextEncoder().encode(JSON.stringify(header))
  const length = new Uint8Array(4)
  new DataView(length.buffer).setUint32(0, headerBytes.length)
  return {
    blob: new Blob([MAGIC_V2, length, headerBytes, cipher], { type: 'application/octet-stream' }),
    fingerprint,
    size: file.size,
  }
}

export type CopyFormat = 'v1' | 'v2' | 'unknown'

export async function copyFormat(blob: Blob): Promise<CopyFormat> {
  const head = new Uint8Array(await blob.slice(0, 4).arrayBuffer())
  if (head.length === 4 && MAGIC_V2.every((b, i) => head[i] === b)) return 'v2'
  if (head.length === 4 && MAGIC_V1.every((b, i) => head[i] === b)) return 'v1'
  return 'unknown'
}

async function parseV2(blob: Blob): Promise<{ header: Header; cipher: Uint8Array<ArrayBuffer> }> {
  if ((await copyFormat(blob)) !== 'v2') throw new VaultError('This is not an encrypted vault copy.')
  const data = new Uint8Array(await blob.arrayBuffer())
  const length = new DataView(data.buffer).getUint32(4)
  if (8 + length >= data.length) throw new VaultError('The copy is damaged.')
  try {
    const header = JSON.parse(new TextDecoder().decode(data.slice(8, 8 + length))) as Header
    return { header, cipher: new Uint8Array(data.slice(8 + length)) }
  } catch {
    throw new VaultError('The copy is damaged.')
  }
}

async function unpack(plain: Uint8Array<ArrayBuffer>): Promise<DecryptedFile> {
  const metaLength = new DataView(plain.buffer).getUint32(0)
  if (4 + metaLength > plain.length) throw new VaultError('The copy is damaged.')
  const meta = JSON.parse(new TextDecoder().decode(plain.slice(4, 4 + metaLength))) as Meta
  const content = new Uint8Array(plain.slice(4 + metaLength))
  return {
    blob: new Blob([content], { type: meta.type || 'application/octet-stream' }),
    name: meta.name || 'restored-file',
    fingerprint: await sha256Bytes(content),
  }
}

async function open(header: Header, cipher: Uint8Array<ArrayBuffer>, key: CryptoKey): Promise<DecryptedFile> {
  let plain: Uint8Array<ArrayBuffer>
  try {
    plain = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(header.iv) }, key, cipher))
  } catch {
    throw new VaultError('This copy was made with a different vault key. Restore it with its own recovery key.')
  }
  return unpack(plain)
}

export async function decryptWithKey(blob: Blob, key: CryptoKey): Promise<DecryptedFile> {
  const { header, cipher } = await parseV2(blob)
  return open(header, cipher, key)
}

/** Open a copy on a new device with its recovery key, and adopt its vault profile. */
export async function adoptFromCopy(
  blob: Blob,
  recoveryKey: string,
): Promise<{ profile: Profile; key: CryptoKey; file: DecryptedFile }> {
  const { header, cipher } = await parseV2(blob)
  const key = await unwrap(header.recovery, recoveryKey)
  const file = await open(header, cipher, key)
  const profile: Profile = {
    v: 2,
    recovery: header.recovery,
    passkey: header.passkey,
    credentialId: header.credentialId,
    prfSalt: header.prfSalt,
  }
  return { profile, key, file }
}

/** Older single-passphrase copies (IPV1). */
export async function decryptLegacyCopy(encrypted: Blob, passphrase: string): Promise<DecryptedFile> {
  const data = new Uint8Array(await encrypted.arrayBuffer())
  const headerLength = MAGIC_V1.length + SALT_BYTES + IV_BYTES
  if ((await copyFormat(encrypted)) !== 'v1' || data.length <= headerLength) {
    throw new VaultError('This is not an encrypted vault copy.')
  }
  const salt = new Uint8Array(data.slice(MAGIC_V1.length, MAGIC_V1.length + SALT_BYTES))
  const iv = new Uint8Array(data.slice(MAGIC_V1.length + SALT_BYTES, headerLength))
  const cipher = new Uint8Array(data.slice(headerLength))
  try {
    const key = await deriveKey(passphrase, salt)
    return await unpack(new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, cipher)))
  } catch {
    throw new VaultError('Wrong passphrase, or the copy is damaged.')
  }
}
