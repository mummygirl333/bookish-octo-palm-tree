import { Amount, formatUsdc, usdcDecimalsFor } from '@/onchain-money'
import { buildTxExplorerUrl } from '@/onchain-facts'
import { CHAIN_ID } from '@/contracts/registry'

export function shortAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

/** Display a raw USDC amount (6-decimal ERC-20 view). Tiny amounts keep full precision. */
export function fmtUsdc(raw: bigint): string {
  if (raw === 0n) return '0.00'
  if (raw < 10_000n) return formatUsdc(raw)
  return Amount.fromRaw(raw, usdcDecimalsFor(CHAIN_ID)).toFixed(2)
}

export function txUrl(hash: string): string {
  return buildTxExplorerUrl(CHAIN_ID, hash)
}

export function relativeDate(unixSeconds: bigint): string {
  return new Date(Number(unixSeconds) * 1000).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}
