import type { RequestKind } from './requestStore'

/**
 * Plain-language request letter. Placeholders in [brackets] are filled in by the
 * person sending it, outside this app. The app never asks for a legal name,
 * address or ID. This is a template, not legal advice.
 */
export function buildLetter(company: string, kind: RequestKind): string {
  const name = company.trim() || '[Company name]'
  const ask: string[] = []

  if (kind === 'access' || kind === 'both') {
    ask.push(
      `1. Confirm whether you hold personal data about me, including data collected when I was a minor.`,
      `2. Give me a copy of that data, and tell me what categories it covers, where it came from, why you hold it, how long you keep it, and who you have shared it with or sold it to.`,
      `3. Tell me whether any of it was used to build, train or improve software, products or services, and which ones.`,
    )
  }
  if (kind === 'delete' || kind === 'both') {
    const n = ask.length + 1
    ask.push(
      `${n}. Delete the personal data you hold about me and tell any company you shared it with to delete it too.`,
      `${n + 1}. Confirm in writing when the deletion is finished, and if you will not delete something, tell me exactly what and why.`,
    )
  }

  return [
    `[Date]`,
    ``,
    `To: Privacy team, ${name}`,
    ``,
    `Subject: Personal data request`,
    ``,
    `I am writing under any privacy law that applies to me, including state privacy laws and consumer protection law. I am asking you to:`,
    ``,
    ...ask,
    ``,
    `Please also keep all records relating to me while this request is open, and do not delete them except as I have asked above.`,
    ``,
    `Please reply in writing within the time the law requires, and no later than 45 days from today. If you need more time, or you need to confirm who I am, tell me what the minimum necessary is and I will provide it. Please do not ask for more identifying information than the law requires.`,
    ``,
    `If you refuse any part of this request, tell me the reason and how I can appeal.`,
    ``,
    `[Your full name]`,
    `[How to reach you]`,
  ].join('\n')
}
