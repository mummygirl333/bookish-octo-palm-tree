import type { Profile } from './vaultCrypto'

/**
 * The vault profile holds only wrapped keys and a passkey id. None of it is secret
 * on its own: it is useless without the recovery key or the fingerprint or face.
 */
const KEY = 'ip-vault:profile:v2'

export function loadProfile(): Profile | null {
  try {
    const raw = localStorage.getItem(KEY)
    const parsed = raw ? (JSON.parse(raw) as Profile) : null
    return parsed?.v === 2 && parsed.recovery ? parsed : null
  } catch {
    return null
  }
}

export function saveProfile(profile: Profile): void {
  localStorage.setItem(KEY, JSON.stringify(profile))
}
