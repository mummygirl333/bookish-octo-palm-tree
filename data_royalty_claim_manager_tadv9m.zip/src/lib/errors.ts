const KNOWN: Array<[RegExp, string]> = [
  [/PriceTooHigh/i, 'The price changed since you opened this. Refresh and try again.'],
  [/ContentHashRegistered/i, 'This data has already been claimed by someone else.'],
  [/CommitmentNotReady/i, 'Registration step 1 is still confirming. Try again in a moment.'],
  [/CommitmentMissing/i, 'No matching step 1 found for this registration.'],
  [/NotDatasetOwner/i, 'Only the owner of this data can do that.'],
  [/DatasetInactive/i, 'This data is not accepting payments right now.'],
  [/NothingToClaim/i, 'There are no royalties to claim yet.'],
  [/ZeroPrice/i, 'This data has no per-use price set.'],
  [/insufficient funds|exceeds balance|transfer amount exceeds/i, 'Insufficient USDC balance.'],
]

export function isUserRejection(error: unknown): boolean {
  const e = error as { code?: number; message?: string; shortMessage?: string } | null
  const text = `${e?.shortMessage ?? ''} ${e?.message ?? ''}`.toLowerCase()
  return e?.code === 4001 || text.includes('user rejected') || text.includes('user denied')
}

export function parseOnchainError(error: unknown): string {
  const e = error as { shortMessage?: string; message?: string } | null
  const text = `${e?.shortMessage ?? ''} ${e?.message ?? ''}`
  for (const [pattern, message] of KNOWN) {
    if (pattern.test(text)) return message
  }
  if (/network|timeout|fetch/i.test(text)) return 'Network issue. Check your connection and retry.'
  return 'Transaction failed. Please try again.'
}
