import { fromB64, toB64 } from './b64'
import { VaultError } from './vaultCrypto'

export type RequestKind = 'access' | 'delete' | 'both'
export type RequestMethod = 'portal' | 'email' | 'mail'
export type RequestStatus = 'waiting' | 'replied' | 'refused'

export interface DataRequest {
  id: string
  company: string
  kind: RequestKind
  method: RequestMethod
  /** yyyy-mm-dd, the day the request was sent. */
  sentOn: string
  /** How many days the company has to reply before the request counts as overdue. */
  dueInDays: number
  status: RequestStatus
  notes: string
}

/** Stored encrypted with the unlocked vault key. Never leaves this device. */
const STORAGE_KEY = 'ip-vault:requests:v1'
const IV_BYTES = 12
const DAY_MS = 24 * 60 * 60 * 1000

export async function loadRequests(key: CryptoKey): Promise<DataRequest[]> {
  const raw = localStorage.getItem(STORAGE_KEY)
  if (!raw) return []
  try {
    const data = fromB64(raw)
    const plain = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: data.slice(0, IV_BYTES) },
      key,
      data.slice(IV_BYTES),
    )
    return JSON.parse(new TextDecoder().decode(plain)) as DataRequest[]
  } catch {
    throw new VaultError('Your saved requests could not be opened with this vault key.')
  }
}

export async function saveRequests(key: CryptoKey, requests: DataRequest[]): Promise<void> {
  const iv = crypto.getRandomValues(new Uint8Array(IV_BYTES))
  const cipher = new Uint8Array(
    await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(JSON.stringify(requests))),
  )
  const out = new Uint8Array(IV_BYTES + cipher.length)
  out.set(iv, 0)
  out.set(cipher, IV_BYTES)
  localStorage.setItem(STORAGE_KEY, toB64(out))
}

export function dueDate(request: DataRequest): Date {
  const sent = new Date(`${request.sentOn}T00:00:00`)
  return new Date(sent.getTime() + request.dueInDays * DAY_MS)
}

/** Days until the reply is due. Negative once overdue. */
export function daysLeft(request: DataRequest, now: Date = new Date()): number {
  return Math.ceil((dueDate(request).getTime() - now.getTime()) / DAY_MS)
}

export function isOverdue(request: DataRequest, now: Date = new Date()): boolean {
  return request.status === 'waiting' && daysLeft(request, now) < 0
}
