import { fromB64, toB64 } from './b64'
import { VaultError } from './vaultCrypto'

/**
 * A government API key, kept encrypted with the unlocked vault key in this browser.
 * It is never written into the app's code, a file in the project, or a request log.
 */
const STORAGE_KEY = 'ip-vault:gov-api-key:v1'
const IV_BYTES = 12

export function hasGovKey(): boolean {
  return localStorage.getItem(STORAGE_KEY) !== null
}

export async function saveGovKey(sessionKey: CryptoKey, apiKey: string): Promise<void> {
  const iv = crypto.getRandomValues(new Uint8Array(IV_BYTES))
  const cipher = new Uint8Array(
    await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, sessionKey, new TextEncoder().encode(apiKey)),
  )
  const out = new Uint8Array(IV_BYTES + cipher.length)
  out.set(iv, 0)
  out.set(cipher, IV_BYTES)
  localStorage.setItem(STORAGE_KEY, toB64(out))
}

export async function loadGovKey(sessionKey: CryptoKey): Promise<string | null> {
  const raw = localStorage.getItem(STORAGE_KEY)
  if (!raw) return null
  try {
    const data = fromB64(raw)
    const plain = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: data.slice(0, IV_BYTES) },
      sessionKey,
      data.slice(IV_BYTES),
    )
    return new TextDecoder().decode(plain)
  } catch {
    throw new VaultError('Your saved key could not be opened with this vault key.')
  }
}

export function clearGovKey(): void {
  localStorage.removeItem(STORAGE_KEY)
}
