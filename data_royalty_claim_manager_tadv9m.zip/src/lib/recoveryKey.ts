// 32 symbols (no 0, 1, I, O) so a key written on paper is hard to misread.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
const GROUPS = 8
const GROUP_SIZE = 4

/** Matches a generated key, with or without lowercase letters. */
export const RECOVERY_KEY_RE = /^([A-Za-z2-9]{4}-){7}[A-Za-z2-9]{4}$/

/**
 * 32 random symbols from a 32-symbol alphabet = 160 bits of randomness.
 * Uniform because 256 is a multiple of 32.
 */
export function generateRecoveryKey(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(GROUPS * GROUP_SIZE))
  const chars = Array.from(bytes, (b) => ALPHABET[b % ALPHABET.length])
  const groups: string[] = []
  for (let i = 0; i < GROUPS; i++) groups.push(chars.slice(i * GROUP_SIZE, (i + 1) * GROUP_SIZE).join(''))
  return groups.join('-')
}
