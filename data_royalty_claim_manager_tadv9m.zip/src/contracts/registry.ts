import { arcTestnet } from 'viem/chains'
import type { Address } from 'viem'
import { getUsdc, requireChain } from '@/onchain-facts'
import { registryAbi } from './registryAbi'

export { registryAbi }

export const CHAIN_ID = arcTestnet.id
export const CHAIN = requireChain(CHAIN_ID)

const rawAddress = import.meta.env.VITE_ROYALTY_REGISTRY_ADDRESS as string | undefined
export const REGISTRY_ADDRESS: Address | undefined =
  rawAddress && /^0x[0-9a-fA-F]{40}$/.test(rawAddress) ? (rawAddress as Address) : undefined

const usdcFact = getUsdc(CHAIN_ID)
if (!usdcFact) throw new Error(`USDC is not available on chain ${CHAIN_ID}`)
export const USDC_ADDRESS = usdcFact.address as Address

/** Order matches the contract's `kind` values (0..7). */
export const ASSET_KINDS = [
  { id: 0, label: 'Data' },
  { id: 1, label: 'Image or art' },
  { id: 2, label: 'Audio or video' },
  { id: 3, label: 'Writing' },
  { id: 4, label: 'Software' },
  { id: 5, label: 'Design or patent' },
  { id: 6, label: 'Other' },
  { id: 7, label: 'Personal experience or research' },
] as const

export function kindLabel(kind: number): string {
  return ASSET_KINDS.find((k) => k.id === kind)?.label ?? 'Other'
}

export interface AssetView {
  id: bigint
  owner: Address
  active: boolean
  kind: number
  pricePerUse: bigint
  contentHash: `0x${string}`
  uri: string
  licenseUri: string
  createdAt: bigint
  transferable: boolean
  copyrightRef: `0x${string}`
  noticeCount: bigint
  registeredAt: bigint
  totalUses: bigint
  totalEarned: bigint
  unclaimed: bigint
}
