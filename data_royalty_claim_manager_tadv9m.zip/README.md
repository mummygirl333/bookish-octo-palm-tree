# Data Royalty Claim Manager

A USDC royalty registry for intellectual property. Creators register art, writing, software, designs, data and more. Sites that use that work pay royalties per use, and creators claim what they have earned.

Built with [Arc Studio](https://studio.arc.io)

## Features

- Register IP by fingerprint, with a type and an optional link to the license terms. The file is hashed in your browser and never uploaded.
- Two-step registration so nobody can copy your claim while it is pending.
- Sites pay a per-use royalty in USDC, with a price cap that protects them from last-second price changes.
- Works can predate registration: add an optional original creation date.
- Lock a work to your wallet so it can never be transferred and only you can manage it, including personal work such as life experience and research. Only a fingerprint, title and license link are published, never the work itself.
- Reference an existing copyright registration by fingerprint only. No names, biometric or identity data is ever published.
- Record dated notices of unauthorized use, with the fingerprint of your evidence. These are the owner's own statements and are not verified.
- Private vault: encrypt your files on your own device. A paper recovery key is the permanent way in, and your device fingerprint or face can unlock it day to day (the app never sees your biometrics). The vault locks when you leave the tab. keep encrypted copies anywhere, and register a file's fingerprint straight from the vault. Nothing is uploaded. Generate a strong recovery key, save encrypted copies to a drive or folder you own, and check a backup any time. A lost key cannot be recovered.
- Data requests tracker: a plain-language letter template for asking a company what data it holds, for a copy, or for deletion, plus a private list of requests with reply dates and overdue warnings. Encrypted with your vault key and kept on your device only.
- Government records: use your own api.data.gov key to look up public records from a federal agency's API (secure .gov addresses only) and save results as encrypted evidence. The key is stored encrypted on your device and is never put in the app's code.
- Creators claim royalties for one work or all of them at once, and can change the price or pause new payments.

## Tech stack

React, TypeScript, Vite, Tailwind CSS, wagmi, viem, ConnectKit. Solidity contract built with Foundry and OpenZeppelin. Runs on Arc Testnet with USDC.

## Development

Prerequisites: Bun, Foundry.

```
bun install
bun run dev
```

Build the app with `bun run build`. Build the contract with `forge build`. Run the checks with `bun run check`.

### Environment variables

- `VITE_ROYALTY_REGISTRY_ADDRESS`: address of the deployed registry contract on Arc Testnet (currently 0x2ae0c58367359a62cae6149d1e301a9b864705d7). The app shows a "not deployed" notice until it is set.
