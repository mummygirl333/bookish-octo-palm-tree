## Implementation Plan: Data Royalty Claim Manager

### Summary
Rename the app from "IP Royalties" to **Data Royalty Claim Manager** everywhere users and developers see the name. Nothing else changes.

### Architecture
- Blockchain: unchanged, the registry stays on Arc Testnet.
- Contract: unchanged, no redeploy.
- Frontend: text-only changes.
- Wallet: unchanged, ConnectKit.

### Files to Create/Modify
1. `src/App.tsx`: header title becomes "Data Royalty Claim Manager".
2. `index.html`: browser tab title becomes "Data Royalty Claim Manager".
3. `README.md`: top heading renamed.
4. `AGENTS.md`: top heading renamed.

### Build Sequence
1. Edit the four titles.
2. Run lint and typecheck.

### Done When
- [ ] The app header and browser tab show "Data Royalty Claim Manager".
- [ ] README and AGENTS use the new name.
- [ ] Lint and typecheck pass.
