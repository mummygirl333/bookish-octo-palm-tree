# Data Royalty Claim Manager

> Built with Arc Studio - money-powered apps in minutes

This is the **project memory** - what Arc Studio remembers about building this app. It helps future agents (or humans) understand and extend the project.

---

## What This App Does

A USDC royalty registry. Creators register IP (personal experience/research kind 7, art, audio/video, writing, software, design/patent, other) by content hash with an optional license link (commit then reveal), sites pay per-use royalties, contributors claim. Contract: `contracts/IPRoyaltyRegistry.sol` (reviewed, Slither clean). Frontend reads its address from `VITE_ROYALTY_REGISTRY_ADDRESS` in `.env` (restart dev server after setting). ABI in `src/contracts/registryAbi.ts` (regenerate after contract changes). Vault tab (`src/components/VaultView.tsx`, `src/lib/vaultCrypto.ts`, `src/lib/vaultStore.ts`): browser-only encryption: one random master key wrapped by a recovery-key slot (required) and an optional WebAuthn PRF passkey slot (`src/lib/biometric.ts`); IPV2 copies carry the slots so any copy restores on a new device with the recovery key; IPV1 copies still readable. Profile in localStorage (`src/lib/vaultProfile.ts`). Passkeys do not work inside the Arc Studio preview frame and are bound to the origin they were made on. Ciphertext kept in IndexedDB, exportable `.ipvault` copies, no server. Recovery key is never stored. Vault also generates a random recovery key (`src/lib/recoveryKey.ts`), saves copies to a user-chosen folder (File System Access, Chromium only) and tracks `backedUpAt`. Data request tracker (`src/components/RequestTracker.tsx`, `src/lib/requestStore.ts`, `src/lib/requestLetter.ts`): list encrypted with the unlocked vault key in localStorage, overdue warnings shown only while the vault is open (no notifications), letter template uses [bracket] placeholders and never collects a legal name or ID. Government records tool (`src/components/GovApiTool.tsx`, `src/lib/govApi.ts`, `src/lib/govKeyStore.ts`): user types an api.data.gov key, stored encrypted with the vault key in localStorage; requests only to https .gov hosts, no redirects, no credentials; key sent as `X-Api-Key` header by default (query fallback is recorded by dev-only tracing). Browser calls only work if the agency allows CORS. Never write the key into files or chat. Published on Netlify at https://enchanting-biscochitos-747637.netlify.app (built with `bun run build`, deploys `dist`; the registry address is baked in at build time from `.env`). Site was access-protected by Netlify team settings at first deploy. Registration can carry a hash-only `copyrightRef` (never identity or biometric data) and the owner can call `recordNotice` for timestamped, unverified unauthorized-use notices (event + counter only). Registration can lock an asset to the creator (`transferable=false`: no transfer, owner-only management) and declare an original creation date. The UI warns that title, license link and fingerprint are public and permanent. DEPLOYED on Arc Testnet at 0x2ae0c58367359a62cae6149d1e301a9b864705d7 (constructor arg: Arc USDC 0x3600000000000000000000000000000000000000; tx 0x211dcc56e75e123fc641e9fa8cb7e46cd6563b99e69f39ddf27cbae023090ad0). No owner or admin. Reviewed at the thorough level, 95 unit and invariant tests in `contracts/test/`. Known accepted risks: a Circle freeze of the registry's USDC address would pause all claims; a registration reveal stuck across several blocks could be sniped. Address is set in `.env` as VITE_ROYALTY_REGISTRY_ADDRESS.

## Tech Stack

- Frontend: React 18, Vite, TypeScript, Tailwind CSS
- Web3: wagmi v2, viem v2, ConnectKit
- Contracts: Solidity 0.8.28 + Foundry. Sources in `contracts/`, unit tests in `contracts/test/*.t.sol`. Build with `bun run contracts:build` (`forge build`), test with `bun run contracts:test` (`forge test`).
- Wallet: injected (MetaMask, etc.)
- Chain: Arc Testnet (Chain ID: 5042002, imported from `viem/chains`)
- Token: USDC (6 decimals) (Address: 0x3600000000000000000000000000000000000000, Chain: Arc Testnet)
- Toasts: Sonner

## Key Files

- `src/App.tsx` - Main application logic
- `src/components/` - UI components
- `src/config.ts` - wagmi config (chains, connectors, transports)

## Share links

- Starter apps already ship `getShareBase`, `buildShareLink` and `installShareSync` in `src/lib/share.ts`; import them instead of rewriting them.
- Keep shareable state in the URL path or query, not in the `#fragment`.
- Never put a secret (private key, claim secret, seed phrase, session token, API key) in the URL path or query, encoded or not: every in-app path and query is mirrored to the visitor's studio.arc.io address bar and browser history and reaches servers. A bearer claim secret goes only in the `#fragment` appended to the share link (`` `${await buildShareLink('/claim')}#${secret}` ``) and is read from `location.hash` on load. A link to the app's own share URL shown inside the app must be copy-only or open in a new tab with `target="_blank" rel="noopener noreferrer"`.
- Build every link a user copies or sends with `buildShareLink()` from `src/lib/share.ts`.
- Keep the `installShareSync()` call in `src/main.tsx` when editing it; it keeps the Studio address bar in step with in-app navigation.
- Navigate inside the app with relative links.

## To Run

```bash
bun install
bun run dev
```
